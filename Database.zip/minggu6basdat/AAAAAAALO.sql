/* no 1.1 */
SELECT 
    hb.id AS `id hotel`,
    h.code AS `Kode Hotel`,
    IF(hb.price > AVG(hb.price), 'v', ' ') AS `Overprice`
FROM hotels h
JOIN hotel_booking hb ON h.code=hb.hotel_code;
/* no 1.2 */
SELECT c.id AS 'id',c.name AS'nama',c.email AS 'email'
FROM customers c
JOIN luggages l ON c.id = l.customer_id
JOIN planes p ON l.plane_code=p.code
WHERE p.seats LIKE '23';
/* no 1.3 */
SELECT c1.id AS 'id',c.name AS 'name'
FROM customers c1
JOIN tickets ON c1.id = t.customer_id
JOIN countries c ON c.id = t.from
JOIN countries c ON c.id = t.to 
WHERE c1.email LIKE '%yahoo.com';
/* no 1.4 */

/* no 2*/
SELECT b.id AS 'ID', c.nama AS 'Name'
FROM
(SELECT
CASE
WHEN a.nick LIKE '%CU%' THEN CONCAT('CU',UPPER(SUBSTR(a.nick,3,2)),
CASE
WHEN id<10 THEN CONCAT('00',id)
ELSE CONCAT('0',id)
END)

WHEN a.nick LIKE '%CO%' THEN CONCAT('CO',UPPER(SUBSTR(a.nick,3,2)),
CASE
WHEN id<10 THEN CONCAT('00',id)
ELSE CONCAT('0',id)
END)

END AS 'id'
FROM
(SELECT id,CONCAT('CU',SUBSTR(NAME,1,2)) AS 'nick'
FROM customers
WHERE id%5=0
UNION ALL
SELECT id,CONCAT('CO',SUBSTR(NAME,1,2)) AS 'nick'
FROM companies
WHERE id%3=0)a)b
LEFT JOIN
(SELECT id AS 'idnya', NAME AS 'nama'
FROM customers
WHERE id%5=0
UNION ALL
SELECT id AS 'idnya', NAME AS 'nama'
FROM companies
WHERE id%3=0) c ON SUBSTR(b.id,6,2) LIKE c.idnya OR SUBSTR(b.id,7,2) LIKE c.idnya
GROUP BY 2;
/* no 3 */
SELECT c.name, t.code, l.weight
FROM customers c
JOIN tickets t ON c.id = t.customer_id
JOIN flights f ON t.flight_id = f.id
JOIN luggages l ON c.id = l.customer_id
JOIN countries c1 ON t.from = c1.id
WHERE c1.name LIKE '%i%';
/*no 4*/
SELECT 
CASE 
WHEN a.banyak = 1 THEN CONCAT('Hotel ',h.name,' telah dipesan hanya sekali')
ELSE CONCAT('Hotel ',h.name,' telah dipesan lebih dari sekali')
END AS 'Description'
FROM 
(SELECT hotel_code AS 'id', COUNT(id) AS 'banyak'
FROM hotel_booking
GROUP BY 1) a
LEFT JOIN hotels h ON a.id = h.code;