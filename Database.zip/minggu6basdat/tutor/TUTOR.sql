-- Contoh subquery
SELECT s.nama, nu.nilai
FROM siswa s
JOIN nilai_ulangan nu ON s.nomor_induk = nu.no_induk
WHERE nu.nilai > (SELECT AVG(nu.nilai)
FROM nilai_ulangan nu);

-- IF
SELECT s.nama , IF(SUM(nu.nilai) < 90, 'Dibawah 90', 'Diatas 90') AS 'SUM NILAI'
FROM siswa s
JOIN nilai_ulangan nu ON s.nomor_induk = nu.no_induk
GROUP BY s.nama;

-- CASE
SELECT s.nama , 
(CASE
	nu.jenis WHEN 1 THEN 'Jenis Satu'
		WHEN 2 THEN 'Jenis Dua'
		ELSE 'Jenis Tiga'
END) AS 'JENIS'
FROM siswa s
JOIN nilai_ulangan nu ON s.nomor_induk = nu.no_induk
GROUP BY s.nama;

-- HAVING, simplenya adalah where untuk special field seperti count, sum, dsb
SELECT s.nama, SUM(nu.nilai)
FROM siswa s
JOIN nilai_ulangan nu ON s.nomor_induk = nu.no_induk
GROUP BY s.nama
HAVING SUM(nu.nilai) > 90

-- UNION menggabungkan record dari kedua query, jika ada record yang kembar salah satu data akan dieliminasi
-- UNION ALL mirip seperti union tapi, jika ada record yang kembar maka tidak dieliminasi
-- syarat : TIPE DATA dan NAMA FIELD yang digabungkan harus sama
SELECT CONCAT('Siswa ',s.nama ,' sedang Belajar ') AS 'TEST'
FROM SISWA s, JADWAL j, KELAS k, MATA_PELAJARAN m
WHERE s.ID_KELAS = k.ID_KELAS AND j.ID_KELAS = k.ID_KELAS AND m.ID = j.ID_MAPEL
AND j.HARI = 'SELASA' AND j.ID_WAKTU = 1
UNION
-- union all
SELECT CONCAT('Guru ',g.nama ,' sedang mengajar ') FROM GURU g, JADWAL j, KELAS k, MATA_PELAJARAN m
WHERE j.ID_KELAS = k.ID_KELAS AND m.ID = j.ID_MAPEL AND g.ID_GURU = j.ID_GURU
AND j.HARI = 'SELASA' AND j.ID_WAKTU = 1
ORDER BY 1;

-- Mengembalikan record yang sama dengan record subquery
SELECT NAMA FROM guru WHERE ID_GURU
IN (SELECT g.ID_GURU FROM GURU g, JADWAL j WHERE g.ID_GURU = j.ID_GURU AND j.HARI = 'SELASA')
ORDER BY 1;

-- Operator yang membandingkna record antara 2 query secara korelasi
SELECT * FROM guru WHERE EXISTS	
(SELECT g.ID_GURU FROM GURU g, JADWAL j WHERE g.ID_GURU = j.ID_GURU AND j.HARI = 'SELASA')
ORDER BY 1;

-- mengurangi record dari query pertama dengan record dari query kedua
SELECT nomor_induk, nama FROM siswa
EXCEPT
SELECT nomor_induk, nama FROM nilai_ulangan, siswa WHERE nilai_ulangan.no_induk = siswa.nomor_induk

-- seperti union, mengembalikan record dari kedua query
SELECT nomor_induk, nama FROM siswa
INTERSECT
SELECT nomor_induk, nama FROM nilai_ulangan, siswa WHERE nilai_ulangan.no_induk = siswa.nomor_induk