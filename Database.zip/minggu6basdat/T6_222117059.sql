SELECT c.name AS Customer,
    t.code AS 'Kode Tiket',
    l.weight AS 'Berat Barang'
FROM customers c
    JOIN tickets t
    ON c.id=t.customer_id
    JOIN flights f
    ON t.flight_id=f.id
    JOIN luggages l
    ON c.id=l.customer_id
    JOIN countries cs
    ON t.from=cs.id
WHERE cs.name LIKE'%i%'
GROUP BY 2
ASC;