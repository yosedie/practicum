DELIMITER$$
CREATE OR REPLACE PROCEDURE tugas2(IN htrans_code VARCHAR(10))
BEGIN
DECLARE fin INT DEFAULT 0;
DECLARE ctr INT DEFAULT 0;
DECLARE CODE VARCHAR(255)DEFAULT'';
DECLARE NAME VARCHAR(255)DEFAULT'';
DECLARE dates VARCHAR(255)DEFAULT'';
DECLARE pcode VARCHAR(255)DEFAULT'';
DECLARE fname VARCHAR(255)DEFAULT'';
DECLARE tname VARCHAR(255)DEFAULT'';
DECLARE res VARCHAR(16383)DEFAULT'';
DECLARE curTrans CURSOR FOR
SELECT h.code,c.name,h.date,f.plane_code,c2.name,c3.name
FROM htrans h
JOIN customers c ON h.customer_id=c.id
JOIN dtrans d ON h.code=d.header_code
JOIN tickets t ON d.ticket_code=t.code
JOIN flights f ON t.flight_id=f.id
JOIN countries c2 ON c2.id=t.from
JOIN countries c3 ON c3.id=t.to
WHERE h.code=htrans_code;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fin=1;
SET res='';
OPEN curTrans;
getTrans:LOOP
FETCH curTrans INTO CODE,NAME,dates,pcode,fname,tname;
IF(fin=1)THEN
LEAVE getTrans;
END IF;
IF ctr=0 THEN
SET res=CONCAT(res,'==================================================\n');
SET res=CONCAT(res,'#                       Transaction Code : ',CODE,' #\n');
SET res=CONCAT(res,'# Customer Name  : ',RPAD(NAME,30,' '),'#\n');
SET res=CONCAT(res,'# Purchase Date  : ',RPAD(dates,30,' '),'#\n');
SET res=CONCAT(res,'--------------------------------------------------\n');
SET res=CONCAT(res,'# Flights                                        #\n');
SET ctr=1;
END IF;
SET res=CONCAT(res,'--------------------------------------------------\n');
SET res=CONCAT(res,'# Pesawat : ',RPAD(pcode,37,' '),'#\n');
SET res=CONCAT(res,'# Depature : ',RPAD(fname,36,' '),'#\n');
SET res=CONCAT(res,'# Arrival : ',RPAD(tname,37,' '),'#\n');
END LOOP;
SET res=CONCAT(res,'==================================================\n');
CLOSE curTrans;
SELECT res;
END$$
DELIMITER;