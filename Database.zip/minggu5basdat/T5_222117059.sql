--nomor1.
--1
SELECT c0.name AS Nama,
COUNT(DISTINCT f.departure)
AS`Depature Count`,
COUNT(DISTINCT f.arrival)
AS`Arrival Count`
FROM flights f
JOIN countries c0
ON f.departure=c0.id
JOIN countries c1
ON f.arrival=c1.id
GROUP BY Nama;
--2
SELECT c.name
AS Nama,COUNT(l.id)
AS`Jumlah Barang`,SUM(l.weight)
AS`Total Berat`
FROM customers c
LEFT JOIN luggages l
ON c.id=l.customer_id
GROUP BY c.id
ORDER BY `Total Berat`DESC;
--3
SELECT hotels.name AS'Nama',
    hotels.code AS'Book Count'
FROM hotels
ORDER BY hotels.code DESC;
--4

--5

--nomor2.
SELECT t.code AS'Kode Tiket',
    DATE_FORMAT(f.departure_date,'%d%b%Y')
AS'Tanggal Keberangkatan',
    CONCAT("[HP] ",c.phone_number," [", 
UPPER(SUBSTRING(c.email,LOCATE('@',c.email)+1,
LENGTH(c.email)-LOCATE('@', c.email)-3)),"] ",
c.email)AS'Kontak Customer'
FROM tickets t
    JOIN flights f ON t.flight_id=f.id
    JOIN customers c ON t.customer_id=c.id
order by 1;

--nomor3.
SELECT CONCAT('[CUS',UPPER(SUBSTR(c.name,1,1)),
SUBSTR(c.name,INSTR(c.name,' ')+1,1),
SUBSTR(CONVERT(DATE_FORMAT(c.birthdate,'%m'),INT),1,1),
SUBSTR(CONVERT(DATE_FORMAT(c.birthdate,'%d'),INT),1,1),']')
AS"Customer",CONCAT("Meningap di [HO",SUBSTR(h.code,5,1),
SUBSTR(hb.id,1,1),"] ",h.name," Selama ",hb.duration," hari")
AS"Deskripsi"FROM customers c
JOIN hotel_booking hb ON c.id=hb.customer_id
JOIN hotels h ON h.code=hb.hotel_code
ORDER BY CONCAT(SUBSTR(CONVERT(DATE_FORMAT(birthdate, '%m'),INT),1,1),SUBSTR(CONVERT(DATE_FORMAT(birthdate,'%d'),INT),1,1))DESC,
CONCAT(UPPER(SUBSTR(c.name,1,1)),SUBSTR(c.name,INSTR(c.name,' ')+1,1))DESC,
CONCAT(SUBSTR(h.code,5,1),SUBSTR(hb.id,1,1))DESC,
SUBSTR(h.code,5,1);

--nomor4.
SELECT f.plane_code AS'Kode Pesawat', t.code AS'Kode Tiket',
    CASE WHEN DATEDIFF(f.arrival_date,f.departure_date)=0
THEN'Pesawat tiba di hari yang sama'
WHEN DATEDIFF(f.arrival_date,f.departure_date)=1
THEN'Pesawat tiba di hari setelah'
ELSE'Lebih dari satu hari'END AS'Deskripsi'
FROM(SELECT f.id, f.plane_code, f.departure_date,
        DATE_ADD(f.departure_date,
INTERVAL TIME_TO_SEC(f.arrival_time)
SECOND
)AS arrival_date FROM flights f
)AS f JOIN tickets t ON f.id=t.flight_id
order by 3;
