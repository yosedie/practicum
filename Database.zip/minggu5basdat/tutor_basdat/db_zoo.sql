/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 10.4.24-MariaDB : Database - db_zoo
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_zoo` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `db_zoo`;

/*Table structure for table `animals` */

DROP TABLE IF EXISTS `animals`;

CREATE TABLE `animals` (
  `animal_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `species` varchar(50) NOT NULL,
  `exhibit_id` int(11) NOT NULL,
  PRIMARY KEY (`animal_id`),
  KEY `exhibit_id` (`exhibit_id`),
  CONSTRAINT `animals_ibfk_1` FOREIGN KEY (`exhibit_id`) REFERENCES `exhibits` (`exhibit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `animals` */

insert  into `animals`(`animal_id`,`name`,`species`,`exhibit_id`) values 
(1,'Lion','Panthera leo',1),
(2,'Giraffe','Giraffa camelopardalis',2),
(3,'Penguin','Spheniscidae',3),
(4,'Elephant','Elephantidae',4),
(5,'Gorilla','Gorilla beringei',5),
(6,'Zebra','Equus quagga',2),
(7,'Tiger','Panthera tigris',1),
(8,'Kangaroo','Macropus',6),
(9,'Flamingo','Phoenicopterus',3),
(10,'Crocodile','Crocodylus',7);

/*Table structure for table `employees` */

DROP TABLE IF EXISTS `employees`;

CREATE TABLE `employees` (
  `employee_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `salary` decimal(10,2) NOT NULL,
  `reports_to` int(11) DEFAULT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `employees` */

insert  into `employees`(`employee_id`,`name`,`position`,`salary`,`reports_to`) values 
(1,'John Doe','Zookeeper',35000.00,8),
(2,'Jane Smith','Veterinarian',70000.00,4),
(3,'Bob Johnson','Maintenance',25000.00,4),
(4,'Samantha Lee','Curator',50000.00,8),
(5,'David Wilson','Security',20000.00,1),
(6,'Mary Rodriguez','Marketing',40000.00,8),
(7,'Alex Nguyen','Food Service',15000.00,6),
(8,'Dave Gibson','Supervisor',30000.00,NULL);

/*Table structure for table `exhibits` */

DROP TABLE IF EXISTS `exhibits`;

CREATE TABLE `exhibits` (
  `exhibit_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`exhibit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `exhibits` */

insert  into `exhibits`(`exhibit_id`,`name`,`description`) values 
(1,'Big Cat Habitat','Lions and tigers'),
(2,'Safari Zone','Giraffes and zebras'),
(3,'Penguin House','Penguins and flamingos'),
(4,'Elephant Enclosure','Elephants and other large mammals'),
(5,'Primate Pavilion','Gorillas and other primates'),
(6,'Australian Outback','Kangaroos and other native animals'),
(7,'Reptile House','Snakes, lizards, and crocodiles'),
(8,'Aquarium','Fish');

/*Table structure for table `feeding_schedule` */

DROP TABLE IF EXISTS `feeding_schedule`;

CREATE TABLE `feeding_schedule` (
  `feeding_id` int(11) NOT NULL,
  `exhibit_id` int(11) NOT NULL,
  `animal_id` int(11) NOT NULL,
  `time` time NOT NULL,
  `food` varchar(255) NOT NULL,
  PRIMARY KEY (`feeding_id`),
  KEY `exhibit_id` (`exhibit_id`),
  KEY `animal_id` (`animal_id`),
  CONSTRAINT `feeding_schedule_ibfk_1` FOREIGN KEY (`exhibit_id`) REFERENCES `exhibits` (`exhibit_id`),
  CONSTRAINT `feeding_schedule_ibfk_2` FOREIGN KEY (`animal_id`) REFERENCES `animals` (`animal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `feeding_schedule` */

insert  into `feeding_schedule`(`feeding_id`,`exhibit_id`,`animal_id`,`time`,`food`) values 
(1,1,1,'09:00:00','meat'),
(2,2,2,'10:00:00','vegetables'),
(3,3,3,'11:00:00','fruit'),
(4,4,4,'12:00:00','meat'),
(5,5,5,'13:00:00','vegetables'),
(6,6,6,'14:00:00','fruit'),
(7,7,7,'15:00:00','meat');

/*Table structure for table `tickets` */

DROP TABLE IF EXISTS `tickets`;

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `visitor_id` int(11) NOT NULL,
  `exhibit_id` int(11) NOT NULL,
  `date_purchased` date NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`ticket_id`),
  KEY `visitor_id` (`visitor_id`),
  KEY `exhibit_id` (`exhibit_id`),
  CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`visitor_id`) REFERENCES `visitors` (`visitor_id`),
  CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`exhibit_id`) REFERENCES `exhibits` (`exhibit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `tickets` */

insert  into `tickets`(`ticket_id`,`visitor_id`,`exhibit_id`,`date_purchased`,`price`) values 
(1,1,1,'2023-03-01',10.00),
(2,2,2,'2023-03-02',12.50),
(3,3,3,'2023-03-03',8.00),
(4,4,4,'2023-03-04',9.50),
(5,5,5,'2023-03-05',11.00),
(6,6,6,'2023-03-06',10.00),
(7,7,7,'2023-03-07',9.00);

/*Table structure for table `visitors` */

DROP TABLE IF EXISTS `visitors`;

CREATE TABLE `visitors` (
  `visitor_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `visitors` */

insert  into `visitors`(`visitor_id`,`name`,`email`,`phone`) values 
(1,'John Smith','john.smith@example.com','123-456-7890'),
(2,'Jane Doe','jane.doe@example.com','234-567-8901'),
(3,'Bob Johnson','bob.johnson@example.com','345-678-9012'),
(4,'Samantha Lee','samantha.lee@example.com','456-789-0123'),
(5,'David Wilson','david.wilson@example.com','567-890-1234'),
(6,'Mary Rodriguez','mary.rodriguez@example.com','678-901-2345'),
(7,'Alex Nguyen','alex.nguyen@example.com','789-012-3456'),
(8,'Jason Christopher','jje.christopher@example.com','782-012-3445');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
