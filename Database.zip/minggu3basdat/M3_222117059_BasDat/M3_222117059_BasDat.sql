DROP Table mahasiswa;
CREATE TABLE mahasiswa
(
    mahasiswa_nrp VARCHAR(5) PRIMARY KEY,
    mahasiswa_nama VARCHAR(50) NOT NULL,
    mahasiswa_email VARCHAR(50),
    mahasiswa_angkatan INT(20)
);
INSERT into mahasiswa
    (mahasiswa_nrp,mahasiswa_nama,mahasiswa_email,mahasiswa_angkatan)
values('22011', 'Gabriel Kerr', 'Gabriel Kerr@gmail.com', 20);
INSERT into mahasiswa
    (mahasiswa_nrp,mahasiswa_nama,mahasiswa_email,mahasiswa_angkatan)
values('22012', 'Ebony Davies', 'Ebony Davies@gmail.com', 20);
INSERT into mahasiswa
    (mahasiswa_nrp,mahasiswa_nama,mahasiswa_email,mahasiswa_angkatan)
values('22013', 'Rohan Lawson', 'Rohan Lawson@gmail.com', 20);
INSERT into mahasiswa
    (mahasiswa_nrp,mahasiswa_nama,mahasiswa_email,mahasiswa_angkatan)
values('22014', 'Courtney Meza', 'Courtney Meza@gmail.com', 20);
INSERT into mahasiswa
    (mahasiswa_nrp,mahasiswa_nama,mahasiswa_email,mahasiswa_angkatan)
values('22015', 'Bailey Slater', 'Bailey Slater@gmail.com', 20);

DROP Table guru;
CREATE TABLE guru
(
    guru_ni VARCHAR(5) PRIMARY KEY,
    guru_nama VARCHAR(50) NOT NULL,
    guru_matkul INT(10) CHECK (guru_matkul>0),
    guru_email VARCHAR(50),
    CONSTRAINT guru_unique UNIQUE (guru_ni)
);
INSERT into guru
    (guru_ni,guru_nama,guru_matkul,guru_email)
values('11022', 'Marley Hoffman', 2, 'Marley Hoffman@gmail.com');
INSERT into guru
    (guru_ni,guru_nama,guru_matkul,guru_email)
values('11023', 'Freddie Ball', 1, 'Freddie Ball@gmail.com');
INSERT into guru
    (guru_ni,guru_nama,guru_matkul,guru_email)
values('11024', 'Bryn Powers', 4, 'Bryn Powers@gmail.com');
INSERT into guru
    (guru_ni,guru_nama,guru_matkul,guru_email)
values('11025', 'Dylan Simmons', 3, 'Dylan Simmons@gmail.com');
INSERT into guru
    (guru_ni,guru_nama,guru_matkul,guru_email)
values('11026', 'Erin Ochoa', 5, 'Erin Ochoa@gmail.com');

DROP Table matkul;
CREATE TABLE matkul
(
    matkul_id VARCHAR(5) PRIMARY KEY,
    matkul_nama VARCHAR(50) NOT NULL,
    matkul_pengajar VARCHAR(50),
    matkul_jumlah VARCHAR(50),
    CONSTRAINT matkul_unique UNIQUE (matkul_id)
);
INSERT into matkul
    (matkul_id,matkul_nama,matkul_pengajar,matkul_jumlah)
values('00011', 'Mat', 'Marley Hoffman', "4");
INSERT into matkul
    (matkul_id,matkul_nama,matkul_pengajar,matkul_jumlah)
values('00012', 'IPA', 'Freddie Ball', "1");
INSERT into matkul
    (matkul_id,matkul_nama,matkul_pengajar,matkul_jumlah)
values('00013', 'IPS', 'Bryn Powers', "2");
INSERT into matkul
    (matkul_id,matkul_nama,matkul_pengajar,matkul_jumlah)
values('00014', 'Bahasa', 'Dylan Simmons', "1");
INSERT into matkul
    (matkul_id,matkul_nama,matkul_pengajar,matkul_jumlah)
values('00015', 'Inggris', 'Erin Ochoa', "3");

DROP Table asisten;
CREATE TABLE asisten
(
    asisten_nrp VARCHAR(5) PRIMARY KEY,
    asisten_nama VARCHAR(50) NOT NULL,
    asisten_jenis VARCHAR(6) CHECK (asisten_jenis IN ('aslab', 'asdos')),
    asisten_status VARCHAR(2),
    CONSTRAINT asisten_unique UNIQUE (asisten_nrp)
);
INSERT into asisten
    (asisten_nrp,asisten_nama,asisten_jenis,asisten_status)
values('21019', 'Oakley Robertson', 'asdos', "1");
INSERT into asisten
    (asisten_nrp,asisten_nama,asisten_jenis,asisten_status)
values('21018', 'Kieran Mcleod', 'asdos', "1");
INSERT into asisten
    (asisten_nrp,asisten_nama,asisten_jenis,asisten_status)
values('21017', 'Noor Salazar', 'aslab', "0");
INSERT into asisten
    (asisten_nrp,asisten_nama,asisten_jenis,asisten_status)
values('21016', 'Felix Flynn', 'asdos', "0");
INSERT into asisten
    (asisten_nrp,asisten_nama,asisten_jenis,asisten_status)
values('21015', 'Dale Frank', 'aslab', "1");


DROP Table staff;
CREATE TABLE staff
(
    staff_id VARCHAR(5) PRIMARY KEY,
    staff_nama VARCHAR(11),
    staff_jenis VARCHAR(11),
    staff_status VARCHAR(2)
);
INSERT into staff
    (staff_id,staff_nama,staff_jenis,staff_status)
values('01010', 'Belle', 'kelas', "0");
INSERT into staff
    (staff_id,staff_nama,staff_jenis,staff_status)
values('01011', 'Angel', 'pengumuman', "1");
INSERT into staff
    (staff_id,staff_nama,staff_jenis,staff_status)
values('01012', 'Lennon', 'kelas', "1");
INSERT into staff
    (staff_id,staff_nama,staff_jenis,staff_status)
values('01016', 'Armaan', 'kelas', "1");
INSERT into staff
    (staff_id,staff_nama,staff_jenis,staff_status)
values('01020', 'Willow', 'pengumuman', "0");

DROP Table kelas;
CREATE TABLE kelas
(
    id_kelas VARCHAR(5) PRIMARY KEY,
    nama_kelas VARCHAR(50) NOT NULL,
    lokasi_kelas VARCHAR(6),
    jumlah_mahasiswa INT(15) CHECK (jumlah_mahasiswa>=1),
    CONSTRAINT kelas_unique UNIQUE (id_kelas)
);
INSERT into kelas
    (id_kelas,nama_kelas,lokasi_kelas,jumlah_mahasiswa)
values('011', 'E-301', 'E', 15);
INSERT into kelas
    (id_kelas,nama_kelas,lokasi_kelas,jumlah_mahasiswa)
values('023', 'L-404', 'L', 12);
INSERT into kelas
    (id_kelas,nama_kelas,lokasi_kelas,jumlah_mahasiswa)
values('030', 'N-103', 'N', 1);
INSERT into kelas
    (id_kelas,nama_kelas,lokasi_kelas,jumlah_mahasiswa)
values('009', 'B-303', 'B', 9);
INSERT into kelas
    (id_kelas,nama_kelas,lokasi_kelas,jumlah_mahasiswa)
values('100', 'U-202', 'U', 5);

DROP Table pengumuman;
CREATE TABLE pengumuman
(
    judul VARCHAR(5) PRIMARY KEY,
    isi VARCHAR(20) NOT NULL,
    pengirim VARCHAR(5),
    statuss VARCHAR(2)
);
INSERT into pengumuman
    (judul,isi,pengirim,statuss)
values('1', 'pembayaran', 'Staff', 0);
INSERT into pengumuman
    (judul,isi,pengirim,statuss)
values('2', 'pembersihan', 'Staff', 1);
INSERT into pengumuman
    (judul,isi,pengirim,statuss)
values('3', 'deadline', 'Guru', 1);
INSERT into pengumuman
    (judul,isi,pengirim,statuss)
values('4', 'ujian', 'Guru', 0);
INSERT into pengumuman
    (judul,isi,pengirim,statuss)
values('5', 'kebersamaan', 'Staff', 0);

DROP Table pembayaran;
CREATE TABLE pembayaran
(
    kode INT(10) PRIMARY KEY,
    bukti VARCHAR(5),
    jumlah VARCHAR(5),
    statusss VARCHAR(2),
    CONSTRAINT pembayaran_unique UNIQUE(kode)
);
INSERT into pembayaran
    (kode,bukti,jumlah,statusss)
values(9, 'SPP', '90000', 1);
INSERT into pembayaran
    (kode,bukti,jumlah,statusss)
values(8, 'SPP', '60000', 1);
INSERT into pembayaran
    (kode,bukti,jumlah,statusss)
values(6, 'SKS', '20000', 0);
INSERT into pembayaran
    (kode,bukti,jumlah,statusss)
values(4, 'SKS', '75000', 0);
INSERT into pembayaran
    (kode,bukti,jumlah,statusss)
values(2, 'SPP', '43000', 0);


UPDATE pembayaran SET jumlah="56000" WHERE kode=9;
UPDATE pembayaran SET jumlah="99000" WHERE kode=2;
UPDATE pengumuman SET isi="pemberontakan" WHERE judul="1";
UPDATE pengumuman SET isi="tugas" WHERE judul="3";
UPDATE kelas SET lokasi_kelas="Gedung" WHERE jumlah_mahasiswa=1;
UPDATE kelas SET lokasi_kelas="Kampus" WHERE jumlah_mahasiswa=5;
UPDATE staff SET staff_id="9999" WHERE staff_nama="Belle";
UPDATE asisten SET asisten_nama="Belle" WHERE asisten_nrp="21019";
UPDATE matkul SET matkul_pengajar="jj" WHERE matkul_nama="Mat";
UPDATE guru SET guru_nama="kevin" WHERE guru_ni="11022";
UPDATE mahasiswa SET mahasiswa_nama="yo" WHERE mahasiswa_nrp="22011";


DELETE FROM mahasiswa WHERE mahasiswa_nrp="22011";
DELETE FROM guru WHERE guru_ni="11022";
DELETE FROM matkul WHERE matkul_nama="Mat";
DELETE FROM asisten WHERE asisten_nrp="21019";
DELETE FROM staff WHERE staff_nama="Belle";
DELETE FROM kelas WHERE jumlah_mahasiswa=1;
DELETE FROM pengumuman WHERE judul="1";
DELETE FROM pembayaran WHERE kode=9;