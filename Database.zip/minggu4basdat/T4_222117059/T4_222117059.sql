-- materi1
SELECT p.code, c.name AS company_name, t.name
AS TYPE
FROM planes p
    INNER JOIN companies c ON p.company_id=c.id
    INNER JOIN TYPES t ON p.type=t.id
ORDER BY t.name DESC;
-- materi2
SELECT CONCAT('[',LPAD(f.id,2,'0'),']')AS ID, p.code
AS'CODE', CONCAT(COUNT(p.code),' time(s)')
AS'Departure Amount'
FROM planes p, flights f
WHERE f.plane_code=p.code
    AND YEAR(f.departure_date)<2000
GROUP BY 2
ORDER BY 3,2 DESC;
-- materi3
SELECT CONCAT('[',LPAD(id,2,'0'),'] ',NAME,' is ',
TIMESTAMPDIFF(YEAR,birthdate,CURDATE()),' years old')
AS`Passenger age`FROM`customers`
WHERE TIMESTAMPDIFF
(YEAR,birthdate,CURDATE
())<48
ORDER BY birthdate ASC;
-- materi4
SELECT c.name
AS`Company Name`,c.phone_number AS`Contact Number`,p.code
AS`Plane Code`,CASE p.type WHEN 1 THEN'Airbus'WHEN 2 THEN'Boeing'
END AS`Type`
FROM companies c INNER JOIN planes p ON c.id=p.company_id
WHERE c.name LIKE'%e%'AND p.status=1 ORDER BY c.id ASC;
-- materi5
SELECT c.name AS'Passenger Name', h.name AS'Location', CONCAT(hb.duration,' day(s)')AS'Stay'
, CONCAT('Rp. ',FLOOR(hb.price/hb.duration))AS'Price', CONCAT('Rp. ',hb.price)AS'Subtotal'
FROM customers c, hotels h, hotel_booking hb
WHERE hb.customer_id=c.id AND hb.hotel_code=h.code AND MONTH(hb.date)<5
ORDER BY 3 DESC,FLOOR(hb.price/hb.duration);
-- tugas2
SELECT CONCAT("Penumpang ",c.name," memiliki bagasi seberat ",
SUM(l.weight))AS"Penumpang dengan bagasi > 15kg"
FROM customers c, luggages l
WHERE c.id=l.customer_id
GROUP BY c.id
ORDER BY SUM(l.weight) DESC;
-- tugas3
SELECT c.name AS company, CONCAT(p.code,' [',cl.name,']')
AS plane
FROM companies c JOIN planes p ON c.id=p.company_id
    JOIN classes cl ON p.type=cl.id
WHERE p.code
REGEXP'[13579]$'
ORDER BY c.name;
-- tugas4
SELECT t.code AS'tiket', CONCAT('Pesawat dengan kode ',
p.code,' berangkat dari ',c.name,' ke ',c.name)AS'deskripsi'
FROM tickets t, planes p, flights f, countries c
WHERE t.flight_id=f.id AND f.plane_code=p.code AND(t.from = c.id
    AND LOCATE(' ',c.name)!=0 OR t.to=c.id AND LOCATE(' ',c.name)!=0);
-- tugas5
SELECT h.code AS'transaksi',
    CONCAT((CASE WHEN c.name='Ramon Kilback'
THEN CONCAT('Mr ',c.name)ELSE c.name END),' terbang pada ',
DATE_FORMAT(f.departure_date,'%M %d %Y'))AS'deskripsi'
FROM customers c, dtrans d, flights f, tickets t, htrans h
WHERE d.ticket_code=t.code AND d.header_code=h.code
    AND t.customer_id=c.id AND t.flight_id=f.id
    AND TIMESTAMPDIFF(YEAR,c.birthdate,'2023-03-21')>30
ORDER BY h.code,MONTH(f.departure_date)DESC;
