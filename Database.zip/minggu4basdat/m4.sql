SELECT CASE WHEN d.id=c.id THEN d.header_code
END AS transaksi, CONCAT(CASE WHEN 2023-YEAR(c.birthdate)>30
THEN c.name END,' terbang pada ',CASE
WHEN c.id=f.id THEN f.departure_date END)
AS deskripsi
FROM dtrans d, customers c, flights f
WHERE 2023-YEAR(c.birthdate)>30
ORDER BY d.header_code;

SELECT CONCAT("Penumpang ",c.name," memiliki bagasi seberat ",
SUM(l.weight))AS"Penumpang dengan bagasi > 15kg"
FROM customers c, luggages l WHERE c.id=l.customer_id
GROUP BY c.id ORDER BY SUM(l.weight) DESC;

SELECT h.code AS'transaksi',
    CONCAT((CASE WHEN c.name='Ramon Kilback'
THEN CONCAT('Mr ',c.name)ELSE c.name END),' terbang pada ',
DATE_FORMAT(f.departure_date,'%M %d %Y'))AS'deskripsi'
FROM customers c, dtrans d, flights f, tickets t, htrans h
WHERE d.ticket_code=t.code AND d.header_code=h.code
    AND t.customer_id=c.id AND t.flight_id=f.id
    AND TIMESTAMPDIFF(YEAR,c.birthdate,'2023-03-21')>30
ORDER BY h.code,MONTH(f.departure_date)DESC;
