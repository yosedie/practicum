-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 19, 2023 at 08:12 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_travel`
--
CREATE DATABASE IF NOT EXISTS `db_travel` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `db_travel`;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `name`) VALUES
(1, 'Economy'),
(2, 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `email`, `phone_number`) VALUES
(1, 'Donnelly-Kub', 'samantha13@example.org', '2770379537'),
(2, 'Kilback, Schneider and Bayer', 'darby79@example.net', '4885698347'),
(3, 'Parker, Ortiz and Purdy', 'rollin.johnston@example.net', '8684008326'),
(4, 'Klein LLC', 'marques60@example.net', '5876454353'),
(5, 'Pagac-Ullrich', 'valentina.lesch@example.com', '9364920802'),
(6, 'Ruecker-Cormier', 'quitzon.yadira@example.org', '5523715468'),
(7, 'Hauck, Kunde and Kreiger', 'erik57@example.net', '5024350373'),
(8, 'Leffler-Jast', 'osbaldo.mccullough@example.net', '8170549534'),
(9, 'Hickle-Conn', 'nikita.konopelski@example.com', '1679159870'),
(10, 'Cole PLC', 'marks.lenna@example.com', '7519231571'),
(11, 'Lowe Group', 'canderson@example.org', '5990062143'),
(12, 'Stiedemann-Sipes', 'marc34@example.net', '1640755508'),
(13, 'Koss Ltd', 'coralie.carter@example.org', '6957537507'),
(14, 'McKenzie, Vandervort and Bernhard', 'greenholt.jessie@example.com', '6594878022'),
(15, 'Cummerata, Sporer and Hartmann', 'chyna64@example.net', '5078075723'),
(16, 'Connelly-McGlynn', 'beatty.maia@example.org', '4319226494'),
(17, 'Osinski, Hayes and Parker', 'schneider.cecile@example.org', '6022810901'),
(18, 'Fadel, Purdy and Pagac', 'ffahey@example.net', '8615658846'),
(19, 'Medhurst LLC', 'verna.stamm@example.org', '7735888049'),
(20, 'Sipes, Wunsch and Grady', 'wbreitenberg@example.org', '9414541247');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`) VALUES
(1, 'Bouvet Island (Bouvetoya)'),
(2, 'Sweden'),
(3, 'Marshall Islands'),
(4, 'Yemen'),
(5, 'Nicaragua'),
(6, 'Cook Islands'),
(7, 'Jersey'),
(8, 'Faroe Islands'),
(9, 'Liechtenstein'),
(10, 'Saint Kitts and Nevis'),
(11, 'Macao'),
(12, 'Guatemala'),
(13, 'Uganda'),
(14, 'Mauritania'),
(15, 'Lebanon'),
(16, 'Svalbard & Jan Mayen Islands'),
(17, 'Paraguay'),
(18, 'Faroe Islands'),
(19, 'New Zealand'),
(20, 'Romania');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthdate` date NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `birthdate`, `phone_number`, `gender`) VALUES
(1, 'Meredith Kemmer', 'oreilly.priscilla@gmail.com', '1965-01-09', '7277608875', 'W'),
(2, 'Rosamond Quigley', 'zkoepp@gmail.com', '1975-12-01', '4119024920', 'M'),
(3, 'Gerson Paucek', 'gordon89@gmail.com', '1941-05-23', '9828920661', 'M'),
(4, 'Zechariah Prohaska', 'tcorwin@yahoo.com', '1991-09-23', '9114468462', 'M'),
(5, 'Murl Bernhard', 'patrick.lang@gmail.com', '1936-06-09', '4627600214', 'M'),
(6, 'Lura Morissette', 'rita60@yahoo.com', '1996-11-17', '7177219683', 'W'),
(7, 'Shemar Powlowski', 'hreilly@gmail.com', '1997-05-19', '3102061732', 'M'),
(8, 'Prof. Emory Champlin III', 'stacey52@yahoo.com', '1960-11-11', '7038656773', 'M'),
(9, 'Maggie Kuhn', 'xdurgan@gmail.com', '1925-07-12', '1547912284', 'W'),
(10, 'Dr. Barton Bailey DVM', 'kelli75@gmail.com', '1937-01-15', '2491921558', 'M'),
(11, 'Cierra Carter', 'cjacobi@gmail.com', '2002-11-02', '8436408624', 'W'),
(12, 'Myron Ullrich', 'boyer.kamille@yahoo.com', '1972-11-11', '6255655859', 'M'),
(13, 'Nathan Connelly', 'rgreenfelder@gmail.com', '1974-02-27', '6176230427', 'M'),
(14, 'Karine Parisian', 'tcruickshank@yahoo.com', '1995-07-17', '2938999064', 'W'),
(15, 'Enrique Hintz', 'greenfelder.zelda@yahoo.com', '1932-12-08', '9603932302', 'M'),
(16, 'Ramon Kilback', 'tatyana.mraz@yahoo.com', '1932-07-04', '6448904217', 'M'),
(17, 'Isadore Jakubowski', 'zstoltenberg@yahoo.com', '1960-07-21', '4861740839', 'M'),
(18, 'Jaden Mann', 'khalil75@gmail.com', '1984-02-17', '4092991561', 'M'),
(19, 'Tatum Lesch', 'srenner@gmail.com', '2003-05-05', '3019072732', 'W'),
(20, 'Perry McGlynn', 'mariah46@gmail.com', '1958-06-01', '4979765267', 'M');

-- --------------------------------------------------------

--
-- Table structure for table `dtrans`
--

CREATE TABLE `dtrans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `header_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ticket_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dtrans`
--

INSERT INTO `dtrans` (`id`, `header_code`, `ticket_code`, `price`) VALUES
(1, 'TR001', 'TK001', 380000),
(2, 'TR002', 'TK013', 439082),
(3, 'TR001', 'TK005', 640408),
(4, 'TR001', 'TK007', 985680),
(5, 'TR004', 'TK003', 622732),
(6, 'TR005', 'TK009', 185414),
(7, 'TR006', 'TK012', 752755),
(8, 'TR002', 'TK017', 800984),
(9, 'TR009', 'TK004', 943858),
(10, 'TR004', 'TK015', 220028),
(11, 'TR005', 'TK020', 683256),
(12, 'TR008', 'TK018', 693769),
(13, 'TR003', 'TK015', 383077),
(14, 'TR005', 'TK012', 530184),
(15, 'TR007', 'TK005', 268576),
(16, 'TR010', 'TK003', 389166),
(17, 'TR003', 'TK017', 475035),
(18, 'TR008', 'TK019', 640775),
(19, 'TR001', 'TK020', 601113),
(20, 'TR002', 'TK005', 105428);

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE `flights` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_time` time NOT NULL,
  `departure_date` date NOT NULL,
  `plane_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `terminal` int(11) NOT NULL,
  `departure` int(11) NOT NULL,
  `arrival` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`id`, `departure_time`, `arrival_time`, `departure_date`, `plane_code`, `terminal`, `departure`, `arrival`) VALUES
(1, '11:36:30', '20:36:07', '1992-03-23', 'PL004', 14, 1, 6),
(2, '12:44:17', '18:45:47', '1989-04-26', 'PL002', 18, 5, 5),
(3, '06:08:48', '19:40:57', '2007-11-27', 'PL008', 8, 3, 18),
(4, '20:54:46', '10:59:19', '2005-12-02', 'PL001', 15, 16, 2),
(5, '12:13:07', '07:22:25', '1989-09-24', 'PL009', 16, 7, 17),
(6, '10:38:47', '03:08:53', '1994-09-13', 'PL004', 18, 16, 13),
(7, '23:36:08', '11:15:44', '1973-01-26', 'PL002', 16, 9, 12),
(8, '11:23:41', '23:26:14', '2008-07-11', 'PL007', 9, 2, 19),
(9, '05:31:02', '13:42:05', '1984-05-11', 'PL009', 13, 9, 11),
(10, '15:32:16', '10:36:11', '1993-08-08', 'PL002', 5, 11, 6),
(11, '04:56:38', '18:00:41', '1994-09-15', 'PL010', 13, 19, 1),
(12, '14:02:59', '21:14:33', '1986-12-01', 'PL004', 8, 20, 5),
(13, '17:33:33', '04:51:48', '1972-01-29', 'PL005', 4, 16, 2),
(14, '09:26:03', '10:20:08', '1989-01-18', 'PL006', 17, 4, 14),
(15, '02:40:12', '02:57:42', '2021-08-05', 'PL004', 16, 5, 2),
(16, '08:03:00', '04:16:23', '1971-03-07', 'PL003', 2, 18, 9),
(17, '04:03:46', '03:36:51', '1998-02-15', 'PL001', 11, 19, 3),
(18, '22:24:56', '19:52:10', '1978-11-14', 'PL006', 14, 9, 1),
(19, '12:35:34', '19:16:31', '1977-07-03', 'PL003', 4, 1, 18),
(20, '02:57:36', '04:06:50', '2001-07-11', 'PL009', 5, 2, 12);

-- --------------------------------------------------------

--
-- Table structure for table `hotels`
--

CREATE TABLE `hotels` (
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `hotels`
--

INSERT INTO `hotels` (`code`, `name`, `address`, `phone_number`, `email`) VALUES
('HT001', 'Kovacek, Barton and Bashirian', '7552 Rice Plain Suite 051\nKonopelskiton, MS 37551', '904.452.5861', 'brakus.angelita@example.net'),
('HT002', 'Mertz Ltd', '2697 Jacobs Ramp Suite 753\nGerholdview, WY 09412', '1-660-251-1448', 'ondricka.cassie@example.org'),
('HT003', 'Koss, Trantow and Bauch', '26276 Durgan Islands\nEast Katherynberg, IN 64251-0322', '(430) 520-6399', 'claire79@example.org'),
('HT004', 'Conroy Group', '4807 Maudie Turnpike\nMauriceburgh, AZ 63329-7115', '(213) 462-9208', 'bokeefe@example.org'),
('HT005', 'Crooks, Stoltenberg and Mohr', '22280 Wyman Manors\nNorth Thad, VA 18349', '+1-986-706-4788', 'lgusikowski@example.net'),
('HT006', 'Goodwin-Keebler', '50357 Vandervort Viaduct Apt. 426\nMarkusburgh, KS 28581-3944', '1-252-240-9950', 'muller.percival@example.com'),
('HT007', 'Howell, Schultz and Olson', '767 Esperanza Gardens Suite 383\nBaumbachhaven, LA 18370', '+15596385426', 'kub.darian@example.com'),
('HT008', 'Rempel, Quitzon and Schmeler', '768 Mozell Forges\nJavonteside, MT 27535', '+1 (385) 981-4298', 'cleora.zboncak@example.org'),
('HT009', 'McCullough-Sanford', '20842 Antonetta Inlet Apt. 210\nLabadieton, KY 85450', '339-492-4927', 'vrowe@example.net'),
('HT010', 'Beahan, Erdman and Bogisich', '19520 Demario Circle\nNew Cletus, CO 13353-8811', '1-318-329-8143', 'josiah62@example.org'),
('HT011', 'Collins-Schneider', '644 Rachelle Islands\nTaliaside, GA 74856', '+13862657597', 'oconner.gregoria@example.net'),
('HT012', 'Wehner Ltd', '575 Johnston Courts Suite 333\nSouth Rebekaview, IA 17657-1188', '(989) 278-8159', 'emile.herman@example.com'),
('HT013', 'Gerhold, Howe and Donnelly', '1069 Deckow Path\nO\'Haraport, VT 03821-9576', '+1-567-665-0384', 'lockman.chandler@example.org'),
('HT014', 'Metz LLC', '34350 Charlene Meadows\nNorth Portertown, RI 12165-7059', '+1-520-545-2770', 'bergnaum.jacquelyn@example.org'),
('HT015', 'Gutmann-Gislason', '40588 Heidenreich Crossroad\nTrevermouth, WA 23982', '210-584-0889', 'pjacobs@example.com'),
('HT016', 'Schuppe, Shanahan and Sporer', '7055 Stefan Greens Apt. 036\nElmoreland, MI 38947-5372', '1-520-393-6488', 'qgoldner@example.net'),
('HT017', 'Osinski, Hettinger and Howe', '133 Selena Flats\nSolonfurt, CO 75631-9964', '+1 (475) 466-9081', 'zparker@example.com'),
('HT018', 'Ryan Group', '304 Rosalind Alley Apt. 747\nO\'Keefefort, TX 29665-6748', '1-217-982-2570', 'cleora43@example.org'),
('HT019', 'Kshlerin, Braun and Russel', '4297 Roberts Wells Suite 182\nRomamouth, VA 69167', '305.303.7077', 'ayana40@example.net'),
('HT020', 'Goodwin, Corkery and Von', '5192 Hackett Lane\nPort Susieberg, NJ 43228', '(971) 932-9766', 'erdman.lou@example.org');

-- --------------------------------------------------------

-- --------------------------------------------------------

--
-- Table structure for table `hotel_booking`
--

DROP TABLE IF EXISTS `hotel_booking`;
CREATE TABLE `hotel_booking` (
  `id` int(11) NOT NULL,
  `hotel_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `duration` int(3) NOT NULL COMMENT 'in day(s)',
  `price` int(11) NOT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotel_booking`
--

INSERT INTO `hotel_booking` (`id`, `hotel_code`, `customer_id`, `duration`, `price`, `date`) VALUES
(1, 'HT001', 5, 3, 15500000, '2022-02-08'),
(2, 'HT007', 9, 1, 750000, '2022-02-17'),
(3, 'HT019', 3, 2, 834600, '2022-03-10'),
(4, 'HT003', 10, 5, 4630000, '2022-03-30'),
(5, 'HT009', 6, 5, 9574000, '2022-03-31'),
(6, 'HT007', 14, 2, 5462000, '2022-03-07'),
(7, 'HT018', 19, 7, 8354000, '2022-03-31'),
(8, 'HT005', 15, 6, 3299000, '2022-04-24'),
(9, 'HT005', 2, 2, 836100, '2022-04-28'),
(10, 'HT020', 20, 5, 8324000, '2022-05-05'),
(11, 'HT006', 18, 4, 8912300, '2022-05-21'),
(12, 'HT011', 20, 2, 289000, '2022-05-31'),
(13, 'HT007', 16, 6, 9182300, '2022-07-20'),
(14, 'HT017', 9, 2, 812730, '2022-08-12'),
(15, 'HT008', 12, 4, 1892300, '2022-11-16');

-- --------------------------------------------------------

--
-- Table structure for table `htrans`
--

CREATE TABLE `htrans` (
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `htrans`
--

INSERT INTO `htrans` (`code`, `date`, `customer_id`, `total`) VALUES
('TR001', '2022-06-24', 15, 431419),
('TR002', '2022-03-17', 15, 100070),
('TR003', '2022-06-03', 19, 509292),
('TR004', '2022-05-24', 11, 157150),
('TR005', '2022-10-18', 13, 206417),
('TR006', '2022-04-05', 1, 503249),
('TR007', '2023-01-04', 11, 668298),
('TR008', '2022-08-12', 18, 290516),
('TR009', '2022-06-08', 17, 432437),
('TR010', '2022-08-14', 3, 426630);

-- --------------------------------------------------------

--
-- Table structure for table `luggages`
--

CREATE TABLE `luggages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plane_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `weight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `luggages`
--

INSERT INTO `luggages` (`id`, `plane_code`, `customer_id`, `weight`) VALUES
(1, 'PL002', 4, 8),
(2, 'PL002', 16, 13),
(3, 'PL007', 14, 8),
(4, 'PL001', 18, 8),
(5, 'PL003', 6, 11),
(6, 'PL004', 6, 4),
(7, 'PL004', 6, 10),
(8, 'PL010', 10, 3),
(9, 'PL009', 18, 16),
(10, 'PL008', 12, 20),
(11, 'PL001', 5, 18),
(12, 'PL004', 7, 5),
(13, 'PL001', 19, 2),
(14, 'PL007', 16, 1),
(15, 'PL004', 4, 3),
(16, 'PL008', 3, 6),
(17, 'PL009', 10, 8),
(18, 'PL010', 11, 13),
(19, 'PL001', 6, 9),
(20, 'PL002', 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `planes`
--

CREATE TABLE `planes` (
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `seats` int(11) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `planes`
--

INSERT INTO `planes` (`code`, `company_id`, `type`, `seats`, `status`) VALUES
('PL001', 11, 1, 31, 1),
('PL002', 16, 1, 34, 1),
('PL003', 6, 1, 39, 1),
('PL004', 14, 1, 28, 1),
('PL005', 13, 1, 26, 0),
('PL006', 10, 2, 32, 1),
('PL007', 9, 2, 44, 1),
('PL008', 9, 2, 32, 1),
('PL009', 9, 1, 30, 1),
('PL010', 4, 2, 36, 0);

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `plane_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `row` int(11) NOT NULL,
  `column` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `seats`
--

INSERT INTO `seats` (`id`, `plane_code`, `row`, `column`) VALUES
(1, 'PL001', 1, 'A'),
(2, 'PL001', 1, 'B'),
(3, 'PL001', 1, 'C'),
(4, 'PL001', 1, 'D'),
(5, 'PL001', 2, 'A'),
(6, 'PL001', 2, 'B'),
(7, 'PL001', 2, 'C'),
(8, 'PL001', 2, 'D'),
(9, 'PL001', 3, 'A'),
(10, 'PL001', 3, 'B'),
(11, 'PL001', 3, 'C'),
(12, 'PL001', 4, 'A'),
(13, 'PL001', 4, 'B'),
(14, 'PL001', 4, 'C'),
(15, 'PL001', 4, 'D'),
(16, 'PL001', 4, 'E'),
(17, 'PL001', 5, 'A'),
(18, 'PL001', 5, 'B'),
(19, 'PL001', 5, 'C'),
(20, 'PL001', 6, 'A'),
(21, 'PL001', 6, 'B'),
(22, 'PL001', 6, 'C'),
(23, 'PL001', 6, 'D'),
(24, 'PL001', 6, 'E'),
(25, 'PL001', 7, 'A'),
(26, 'PL001', 7, 'B'),
(27, 'PL001', 7, 'C'),
(28, 'PL001', 8, 'A'),
(29, 'PL001', 8, 'B'),
(30, 'PL001', 8, 'C'),
(31, 'PL001', 8, 'D'),
(32, 'PL002', 1, 'A'),
(33, 'PL002', 1, 'B'),
(34, 'PL002', 1, 'C'),
(35, 'PL002', 1, 'D'),
(36, 'PL002', 2, 'A'),
(37, 'PL002', 2, 'B'),
(38, 'PL002', 2, 'C'),
(39, 'PL002', 2, 'D'),
(40, 'PL002', 3, 'A'),
(41, 'PL002', 3, 'B'),
(42, 'PL002', 3, 'C'),
(43, 'PL002', 3, 'D'),
(44, 'PL002', 4, 'A'),
(45, 'PL002', 4, 'B'),
(46, 'PL002', 4, 'C'),
(47, 'PL002', 4, 'D'),
(48, 'PL002', 4, 'E'),
(49, 'PL002', 5, 'A'),
(50, 'PL002', 5, 'B'),
(51, 'PL002', 5, 'C'),
(52, 'PL002', 5, 'D'),
(53, 'PL002', 6, 'A'),
(54, 'PL002', 6, 'B'),
(55, 'PL002', 6, 'C'),
(56, 'PL002', 6, 'D'),
(57, 'PL002', 7, 'A'),
(58, 'PL002', 7, 'B'),
(59, 'PL002', 7, 'C'),
(60, 'PL002', 8, 'A'),
(61, 'PL002', 8, 'B'),
(62, 'PL002', 8, 'C'),
(63, 'PL002', 9, 'A'),
(64, 'PL002', 9, 'B'),
(65, 'PL002', 9, 'C'),
(66, 'PL003', 1, 'A'),
(67, 'PL003', 1, 'B'),
(68, 'PL003', 1, 'C'),
(69, 'PL003', 1, 'D'),
(70, 'PL003', 2, 'A'),
(71, 'PL003', 2, 'B'),
(72, 'PL003', 2, 'C'),
(73, 'PL003', 2, 'D'),
(74, 'PL003', 3, 'A'),
(75, 'PL003', 3, 'B'),
(76, 'PL003', 3, 'C'),
(77, 'PL003', 4, 'A'),
(78, 'PL003', 4, 'B'),
(79, 'PL003', 4, 'C'),
(80, 'PL003', 4, 'D'),
(81, 'PL003', 4, 'E'),
(82, 'PL003', 5, 'A'),
(83, 'PL003', 5, 'B'),
(84, 'PL003', 5, 'C'),
(85, 'PL003', 5, 'D'),
(86, 'PL003', 6, 'A'),
(87, 'PL003', 6, 'B'),
(88, 'PL003', 6, 'C'),
(89, 'PL003', 6, 'D'),
(90, 'PL003', 7, 'A'),
(91, 'PL003', 7, 'B'),
(92, 'PL003', 7, 'C'),
(93, 'PL003', 7, 'D'),
(94, 'PL003', 8, 'A'),
(95, 'PL003', 8, 'B'),
(96, 'PL003', 8, 'C'),
(97, 'PL003', 9, 'A'),
(98, 'PL003', 9, 'B'),
(99, 'PL003', 9, 'C'),
(100, 'PL003', 9, 'D'),
(101, 'PL003', 10, 'A'),
(102, 'PL003', 10, 'B'),
(103, 'PL003', 10, 'C'),
(104, 'PL003', 10, 'D'),
(105, 'PL004', 1, 'A'),
(106, 'PL004', 1, 'B'),
(107, 'PL004', 1, 'C'),
(108, 'PL004', 1, 'D'),
(109, 'PL004', 2, 'A'),
(110, 'PL004', 2, 'B'),
(111, 'PL004', 2, 'C'),
(112, 'PL004', 3, 'A'),
(113, 'PL004', 3, 'B'),
(114, 'PL004', 3, 'C'),
(115, 'PL004', 4, 'A'),
(116, 'PL004', 4, 'B'),
(117, 'PL004', 4, 'C'),
(118, 'PL004', 5, 'A'),
(119, 'PL004', 5, 'B'),
(120, 'PL004', 5, 'C'),
(121, 'PL004', 5, 'D'),
(122, 'PL004', 6, 'A'),
(123, 'PL004', 6, 'B'),
(124, 'PL004', 6, 'C'),
(125, 'PL004', 6, 'D'),
(126, 'PL004', 7, 'A'),
(127, 'PL004', 7, 'B'),
(128, 'PL004', 7, 'C'),
(129, 'PL004', 8, 'A'),
(130, 'PL004', 8, 'B'),
(131, 'PL004', 8, 'C'),
(132, 'PL004', 8, 'D'),
(133, 'PL005', 1, 'A'),
(134, 'PL005', 1, 'B'),
(135, 'PL005', 1, 'C'),
(136, 'PL005', 2, 'A'),
(137, 'PL005', 2, 'B'),
(138, 'PL005', 2, 'C'),
(139, 'PL005', 2, 'D'),
(140, 'PL005', 3, 'A'),
(141, 'PL005', 3, 'B'),
(142, 'PL005', 3, 'C'),
(143, 'PL005', 4, 'A'),
(144, 'PL005', 4, 'B'),
(145, 'PL005', 4, 'C'),
(146, 'PL005', 5, 'A'),
(147, 'PL005', 5, 'B'),
(148, 'PL005', 5, 'C'),
(149, 'PL005', 6, 'A'),
(150, 'PL005', 6, 'B'),
(151, 'PL005', 6, 'C'),
(152, 'PL005', 6, 'D'),
(153, 'PL005', 7, 'A'),
(154, 'PL005', 7, 'B'),
(155, 'PL005', 7, 'C'),
(156, 'PL005', 8, 'A'),
(157, 'PL005', 8, 'B'),
(158, 'PL005', 8, 'C'),
(159, 'PL006', 1, 'A'),
(160, 'PL006', 1, 'B'),
(161, 'PL006', 1, 'C'),
(162, 'PL006', 1, 'D'),
(163, 'PL006', 2, 'A'),
(164, 'PL006', 2, 'B'),
(165, 'PL006', 2, 'C'),
(166, 'PL006', 2, 'D'),
(167, 'PL006', 2, 'E'),
(168, 'PL006', 3, 'A'),
(169, 'PL006', 3, 'B'),
(170, 'PL006', 3, 'C'),
(171, 'PL006', 3, 'D'),
(172, 'PL006', 4, 'A'),
(173, 'PL006', 4, 'B'),
(174, 'PL006', 4, 'C'),
(175, 'PL006', 5, 'A'),
(176, 'PL006', 5, 'B'),
(177, 'PL006', 5, 'C'),
(178, 'PL006', 5, 'D'),
(179, 'PL006', 6, 'A'),
(180, 'PL006', 6, 'B'),
(181, 'PL006', 6, 'C'),
(182, 'PL006', 7, 'A'),
(183, 'PL006', 7, 'B'),
(184, 'PL006', 7, 'C'),
(185, 'PL006', 7, 'D'),
(186, 'PL006', 7, 'E'),
(187, 'PL006', 8, 'A'),
(188, 'PL006', 8, 'B'),
(189, 'PL006', 8, 'C'),
(190, 'PL006', 8, 'D'),
(191, 'PL007', 1, 'A'),
(192, 'PL007', 1, 'B'),
(193, 'PL007', 1, 'C'),
(194, 'PL007', 2, 'A'),
(195, 'PL007', 2, 'B'),
(196, 'PL007', 2, 'C'),
(197, 'PL007', 2, 'D'),
(198, 'PL007', 2, 'E'),
(199, 'PL007', 3, 'A'),
(200, 'PL007', 3, 'B'),
(201, 'PL007', 3, 'C'),
(202, 'PL007', 3, 'D'),
(203, 'PL007', 4, 'A'),
(204, 'PL007', 4, 'B'),
(205, 'PL007', 4, 'C'),
(206, 'PL007', 4, 'D'),
(207, 'PL007', 4, 'E'),
(208, 'PL007', 5, 'A'),
(209, 'PL007', 5, 'B'),
(210, 'PL007', 5, 'C'),
(211, 'PL007', 5, 'D'),
(212, 'PL007', 6, 'A'),
(213, 'PL007', 6, 'B'),
(214, 'PL007', 6, 'C'),
(215, 'PL007', 6, 'D'),
(216, 'PL007', 7, 'A'),
(217, 'PL007', 7, 'B'),
(218, 'PL007', 7, 'C'),
(219, 'PL007', 7, 'D'),
(220, 'PL007', 7, 'E'),
(221, 'PL007', 8, 'A'),
(222, 'PL007', 8, 'B'),
(223, 'PL007', 8, 'C'),
(224, 'PL007', 8, 'D'),
(225, 'PL007', 8, 'E'),
(226, 'PL007', 9, 'A'),
(227, 'PL007', 9, 'B'),
(228, 'PL007', 9, 'C'),
(229, 'PL007', 9, 'D'),
(230, 'PL007', 9, 'E'),
(231, 'PL007', 10, 'A'),
(232, 'PL007', 10, 'B'),
(233, 'PL007', 10, 'C'),
(234, 'PL007', 10, 'D'),
(235, 'PL008', 1, 'A'),
(236, 'PL008', 1, 'B'),
(237, 'PL008', 1, 'C'),
(238, 'PL008', 1, 'D'),
(239, 'PL008', 2, 'A'),
(240, 'PL008', 2, 'B'),
(241, 'PL008', 2, 'C'),
(242, 'PL008', 2, 'D'),
(243, 'PL008', 3, 'A'),
(244, 'PL008', 3, 'B'),
(245, 'PL008', 3, 'C'),
(246, 'PL008', 4, 'A'),
(247, 'PL008', 4, 'B'),
(248, 'PL008', 4, 'C'),
(249, 'PL008', 4, 'D'),
(250, 'PL008', 5, 'A'),
(251, 'PL008', 5, 'B'),
(252, 'PL008', 5, 'C'),
(253, 'PL008', 6, 'A'),
(254, 'PL008', 6, 'B'),
(255, 'PL008', 6, 'C'),
(256, 'PL008', 7, 'A'),
(257, 'PL008', 7, 'B'),
(258, 'PL008', 7, 'C'),
(259, 'PL008', 8, 'A'),
(260, 'PL008', 8, 'B'),
(261, 'PL008', 8, 'C'),
(262, 'PL008', 8, 'D'),
(263, 'PL008', 8, 'E'),
(264, 'PL008', 9, 'A'),
(265, 'PL008', 9, 'B'),
(266, 'PL008', 9, 'C'),
(267, 'PL009', 1, 'A'),
(268, 'PL009', 1, 'B'),
(269, 'PL009', 1, 'C'),
(270, 'PL009', 2, 'A'),
(271, 'PL009', 2, 'B'),
(272, 'PL009', 2, 'C'),
(273, 'PL009', 2, 'D'),
(274, 'PL009', 3, 'A'),
(275, 'PL009', 3, 'B'),
(276, 'PL009', 3, 'C'),
(277, 'PL009', 3, 'D'),
(278, 'PL009', 4, 'A'),
(279, 'PL009', 4, 'B'),
(280, 'PL009', 4, 'C'),
(281, 'PL009', 4, 'D'),
(282, 'PL009', 5, 'A'),
(283, 'PL009', 5, 'B'),
(284, 'PL009', 5, 'C'),
(285, 'PL009', 5, 'D'),
(286, 'PL009', 6, 'A'),
(287, 'PL009', 6, 'B'),
(288, 'PL009', 6, 'C'),
(289, 'PL009', 6, 'D'),
(290, 'PL009', 7, 'A'),
(291, 'PL009', 7, 'B'),
(292, 'PL009', 7, 'C'),
(293, 'PL009', 8, 'A'),
(294, 'PL009', 8, 'B'),
(295, 'PL009', 8, 'C'),
(296, 'PL009', 8, 'D'),
(297, 'PL010', 1, 'A'),
(298, 'PL010', 1, 'B'),
(299, 'PL010', 1, 'C'),
(300, 'PL010', 1, 'D'),
(301, 'PL010', 1, 'E'),
(302, 'PL010', 2, 'A'),
(303, 'PL010', 2, 'B'),
(304, 'PL010', 2, 'C'),
(305, 'PL010', 2, 'D'),
(306, 'PL010', 3, 'A'),
(307, 'PL010', 3, 'B'),
(308, 'PL010', 3, 'C'),
(309, 'PL010', 3, 'D'),
(310, 'PL010', 4, 'A'),
(311, 'PL010', 4, 'B'),
(312, 'PL010', 4, 'C'),
(313, 'PL010', 4, 'D'),
(314, 'PL010', 4, 'E'),
(315, 'PL010', 5, 'A'),
(316, 'PL010', 5, 'B'),
(317, 'PL010', 5, 'C'),
(318, 'PL010', 6, 'A'),
(319, 'PL010', 6, 'B'),
(320, 'PL010', 6, 'C'),
(321, 'PL010', 6, 'D'),
(322, 'PL010', 7, 'A'),
(323, 'PL010', 7, 'B'),
(324, 'PL010', 7, 'C'),
(325, 'PL010', 8, 'A'),
(326, 'PL010', 8, 'B'),
(327, 'PL010', 8, 'C'),
(328, 'PL010', 8, 'D'),
(329, 'PL010', 9, 'A'),
(330, 'PL010', 9, 'B'),
(331, 'PL010', 9, 'C'),
(332, 'PL010', 9, 'D');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` int(11) NOT NULL,
  `flight_id` int(11) NOT NULL,
  `seat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class_id` int(11) NOT NULL,
  `from` int(11) NOT NULL,
  `to` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`code`, `customer_id`, `flight_id`, `seat_id`, `class_id`, `from`, `to`) VALUES
('TK001', 6, 4, '9', 1, 7, 1),
('TK002', 6, 16, '3', 1, 2, 9),
('TK003', 3, 10, '20', 2, 10, 1),
('TK004', 14, 16, '16', 1, 13, 3),
('TK005', 7, 16, '18', 2, 1, 10),
('TK006', 1, 1, '1', 2, 8, 5),
('TK007', 5, 9, '14', 2, 6, 10),
('TK008', 10, 17, '6', 1, 8, 2),
('TK009', 16, 12, '9', 1, 20, 12),
('TK010', 5, 13, '20', 2, 17, 5),
('TK011', 4, 9, '18', 1, 4, 11),
('TK012', 11, 1, '20', 1, 20, 9),
('TK013', 16, 2, '16', 1, 12, 18),
('TK014', 19, 20, '15', 1, 1, 3),
('TK015', 11, 12, '11', 2, 8, 19),
('TK016', 20, 4, '16', 2, 17, 19),
('TK017', 15, 4, '13', 1, 5, 2),
('TK018', 3, 19, '11', 2, 5, 7),
('TK019', 3, 13, '7', 1, 13, 12),
('TK020', 8, 1, '15', 1, 5, 14);

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `name`) VALUES
(1, 'Airbus'),
(2, 'Boeing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dtrans`
--
ALTER TABLE `dtrans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `flights`
--
ALTER TABLE `flights`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `luggages`
--
ALTER TABLE `luggages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `dtrans`
--
ALTER TABLE `dtrans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `flights`
--
ALTER TABLE `flights`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `luggages`
--
ALTER TABLE `luggages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `seats`
--
ALTER TABLE `seats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=333;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
