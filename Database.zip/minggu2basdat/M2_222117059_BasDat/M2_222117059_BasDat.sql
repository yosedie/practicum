DROP Table mahasiswa;
CREATE TABLE mahasiswa
(
    mahasiswa_nrp VARCHAR(5) PRIMARY KEY,
    mahasiswa_nama VARCHAR(50) NOT NULL,
    mahasiswa_email VARCHAR(50),
    mahasiswa_angkatan INT(1) CHECK (mahasiswa_angkatan IN ('21', '22')),
    CONSTRAINT mahasiswa_unique UNIQUE (mahasiswa_nrp)
);

DROP Table guru;
CREATE TABLE guru
(
    guru_ni VARCHAR(5) PRIMARY KEY,
    guru_nama VARCHAR(50) NOT NULL,
    guru_matkul INT(10) CHECK (guru_matkul>0),
    guru_email VARCHAR(5),
    CONSTRAINT guru_unique UNIQUE (guru_ni)
);

DROP Table matkul;
CREATE TABLE matkul
(
    matkul_id VARCHAR(5) PRIMARY KEY,
    matkul_nama VARCHAR(50) NOT NULL,
    matkul_pengajar VARCHAR(50),
    matkul_jumlah VARCHAR(50),
    CONSTRAINT matkul_unique UNIQUE (matkul_id),
    FOREIGN KEY(matkul_pengajar)REFERENCES guru(guru_ni)
);

DROP Table asisten;
CREATE TABLE asisten
(
    asisten_nrp VARCHAR(5) PRIMARY KEY,
    asisten_nama VARCHAR(50) NOT NULL,
    asisten_jenis VARCHAR(6) CHECK (asisten_jenis IN ('aslab', 'asdos')),
    asisten_tanggal DATE NOT NULL,
    CONSTRAINT asisten_unique UNIQUE (asisten_nrp),
    FOREIGN KEY(asisten_jenis)REFERENCES guru(guru_ni)
);

DROP Table staff;
CREATE TABLE staff
(
    staff_id VARCHAR(5) PRIMARY KEY,
    staff_nama VARCHAR(5),
    staff_tanggal DATE NOT NULL,
    staff_jenis VARCHAR(6) CHECK (staff_jenis IN ('pengurus kelas', 'pengurus pengumuman'))
);

DROP Table kelas;
CREATE TABLE kelas
(
    id_kelas VARCHAR(5) PRIMARY KEY,
    nama_kelas VARCHAR(50) NOT NULL,
    lokasi_kelas VARCHAR(6) CHECK (lokasi_kelas IN ('gedung a', 'gedung b')),
    jumlah_mahasiswa INT(15) CHECK (jumlah_mahasiswa>=1),
    CONSTRAINT kelas_unique UNIQUE (id_kelas),
    FOREIGN KEY(lokasi_kelas)REFERENCES staff(staff_id)
);

DROP Table pengumuman;
CREATE TABLE pengumuman
(
    judul VARCHAR(5) PRIMARY KEY,
    isi VARCHAR(20) NOT NULL,
    pengirim VARCHAR(5),
    tanggal DATE NOT NULL,
    FOREIGN KEY(pengirim)REFERENCES staff(staff_id)
);

DROP Table pembayaran;
CREATE TABLE pembayaran
(
    kode INT(10) PRIMARY KEY,
    bukti VARCHAR(5),
    jumlah VARCHAR(5),
    tanggal DATE NOT NULL,
    CONSTRAINT pembayaran_unique UNIQUE(kode)
);

ALTER TABLE pembayaran ADD Status VARCHAR(10) CHECK(Status IN ('sudah', 'belum'));
ALTER TABLE pengumuman ADD Total INT(20) NOT NULL;
ALTER TABLE kelas ADD jam_masuk DATE NOT NULL;
ALTER TABLE staff ADD gaji VARCHAR(5);

ALTER TABLE pembayaran DROP COLUMN jumlah;
ALTER TABLE pengumuman DROP COLUMN tanggal;
