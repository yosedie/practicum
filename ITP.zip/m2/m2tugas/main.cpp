#include<iostream>
#include<time.h>
#include<math.h>
using namespace std;
int main()
{
	cout<<"Permainan Angka 4 digit"<<endl;
	cout<<"1. Input angka"<<endl;
	cout<<"2. Random angka"<<endl;
	cout<<">> ";
	int c;
	cin>>c;
	if(c==1)
    {
		int input;
		cout<<""<<endl;
		cout<<"Input angka : ";
		cin>>input;
		cout<<""<<endl;
		int a,b,c,d;
		int a1,b1,c1,d1;
		int a2,b2,c2,d2;
		int a3,b3,c3,d3;
		int a4,b4,c4,d4;
		a=input/1000;
		b=input/100%10;
		c=input/10%10;
		d=input%10;
        a1=a;
        b1=b;
        c1=c;
        d1=d;
        a2=a;
        b2=b;
        c2=c;
        d2=d;
        a3=a;
        b3=b;
        c3=c;
        d3=d;
        a4=a;
        b4=b;
        c4=c;
        d4=d;
        cout<<"==== Hasil ===="<<endl;
        if(a1%2==1||b1%2==1||c1%2==1||d1%2==1)
        {
        if(a1>=b1&&b1>=c1&&c1>=d1){
        if(d1%2==1){
        cout<<"Ganjil terbesar			: "<<a1<<b1<<c1<<d1<<endl;
        }else if(c1%2==1){
        cout<<"Ganjil terbesar			: "<<a1<<b1<<d1<<c1<<endl;
        }else if(b1%2==1){
        cout<<"Ganjil terbesar			: "<<a1<<d1<<c1<<b1<<endl;
        }else{
        cout<<"Ganjil terbesar			: "<<b1<<d1<<c1<<a1<<endl;
        }
        }
        else if(b1>=c1&&c1>=d1&&d1>=a1){
        cout<<"Ganjil terbesar			: "<<b1<<c1<<d1<<a1<<endl;
        }
        else if(c1>=d1&&d1>=a1&&a1>=b1){
        cout<<"Ganjil terbesar			: "<<c1<<d1<<a1<<b1<<endl;
        }
        else if(d1>=a1&&a1>=b1&&b1>=c1){
        cout<<"Ganjil terbesar			: "<<d1<<a1<<b1<<c1<<endl;
        }
        else if(b1>=a1&&a1>=c1&&c1>=d1){
        cout<<"Ganjil terbesar			: "<<b1<<a1<<c1<<d1<<endl;
        }
        else if(c1>=b1&&b1>=a1&&a1>=d1){
        cout<<"Ganjil terbesar			: "<<c1<<b1<<a1<<d1<<endl;
        }
        else if(d1>=b1&&b1>=c1&&c1>=a1){
        cout<<"Ganjil terbesar			: "<<d1<<b1<<c1<<a1<<endl;
        }
        else if(a1>=c1&&c1>=b1&&b1>=d1){
        cout<<"Ganjil terbesar			: "<<a1<<c1<<b1<<d1<<endl;
        }
        else if(a1>=d1&&d1>=c1&&c1>=b1){
        cout<<"Ganjil terbesar			: "<<a1<<d1<<c1<<b1<<endl;
        }
        else if(a1>=b1&&b1>=d1&&d1>=c1){
        cout<<"Ganjil terbesar			: "<<a1<<b1<<d1<<c1<<endl;
        }
        else if(b1>=c1&&c1>=a1&&a1>=d1){
        cout<<"Ganjil terbesar			: "<<b1<<c1<<a1<<d1<<endl;
        }
        else if(c1>=a1&&a1>=b1&&b1>=d1){
        cout<<"Ganjil terbesar			: "<<c1<<a1<<b1<<d1<<endl;
        }
        else if(c1>=a1&&a1>=b1&&b1>=d1){
        cout<<"Ganjil terbesar			: "<<c1<<b1<<d1<<a1<<endl;
        }
        else if(d1>=a1&&a1>=c1&&c1>=b1){
        cout<<"Ganjil terbesar			: "<<d1<<a1<<c1<<b1<<endl;
        }
        else if(c1>=a1&&a1>=b1&&b1>=d1){
        cout<<"Ganjil terbesar			: "<<c1<<b1<<d1<<a1<<endl;
        }
        else if(d1>=c1&&c1>=b1&&b1>=a1){
        if(a1%2==1){
        cout<<"Ganjil terbesar			: "<<d1<<c1<<b1<<a1<<endl;
        }else if(b1%2==1){
        cout<<"Ganjil terbesar			: "<<d1<<c1<<a1<<b1<<endl;
        }else if(c1%2==1){
        cout<<"Ganjil terbesar			: "<<d1<<a1<<b1<<c1<<endl;
        }else{
        cout<<"Ganjil terbesar			: "<<c1<<a1<<b1<<d1<<endl;
        }
        }
        else if(a1>=c1&&c1>=d1&&d1>=b1){
        cout<<"Ganjil terbesar			: "<<a1<<c1<<d1<<b1<<endl;
        }
        else if(a1>=d1&&d1>=b1&&b1>=c1){
        cout<<"Ganjil terbesar			: "<<a1<<d1<<b1<<c1<<endl;
        }
        else if(b1>=a1&&a1>=d1&&d1>=c1){
        cout<<"Ganjil terbesar			: "<<b1<<a1<<d1<<c1<<endl;
        }
        else if(b1>=d1&&d1>=a1&&a1>=c1){
        cout<<"Ganjil terbesar			: "<<b1<<d1<<a1<<c1<<endl;
        }
        else if(b1>=d1&&d1>=c1&&c1>=a1){
        cout<<"Ganjil terbesar			: "<<b1<<d1<<c1<<a1<<endl;
        }
        else if(c1>=a1&&a1>=d1&&d1>=b1){
        cout<<"Ganjil terbesar			: "<<c1<<a1<<d1<<b1<<endl;
        }
        else if(c1>=d1&&d1>=b1&&b1>=a1){
        cout<<"Ganjil terbesar			: "<<c1<<d1<<b1<<a1<<endl;
        }
        else if(d1>=b1&&b1>=a1&&a1>=c1){
        cout<<"Ganjil terbesar			: "<<d1<<b1<<a1<<c1<<endl;
        }
        else if(d1>=c1&&c1>=a1&&a1>=b1){
        cout<<"Ganjil terbesar			: "<<d1<<c1<<a1<<b1<<endl;
        }
        }
        else if(a1%2==0||b1%2==0||c1%2==0||d1%2==0){
        cout<<"Ganjil terbesar			: tidak ada"<<endl;
        }
        if(a2%2==0||b2%2==0||c2%2==0||d2%2==0)
        {
        if(a2>=b2&&b2>=c2&&c2>=d2){
        if(d2%2==0){
        cout<<"Genap terbesar			: "<<a2<<b2<<c2<<d2<<endl;
        }else if(c2%2==0){
        cout<<"Genap terbesar			: "<<a2<<b2<<d2<<c2<<endl;
        }else if(b2%2==0){
        cout<<"Genap terbesar			: "<<a2<<d2<<c2<<b2<<endl;
        }else{
        cout<<"Genap terbesar			: "<<b2<<d2<<c2<<a2<<endl;
        }
        }
        else if(b2>=c2&&c2>=d2&&d2>=a2){
        cout<<"Genap terbesar			: "<<b2<<c2<<d2<<a2<<endl;
        }
        else if(c2>=d2&&d2>=a2&&a2>=b2){
        cout<<"Genap terbesar			: "<<c2<<d2<<a2<<b2<<endl;
        }
        else if(d2>=a2&&a2>=b2&&b2>=c2){
        cout<<"Genap terbesar			: "<<d2<<a2<<b2<<c2<<endl;
        }
        else if(b2>=a2&&a2>=c2&&c2>=d2){
        cout<<"Genap terbesar			: "<<b2<<a2<<c2<<d2<<endl;
        }
        else if(c2>=b2&&b2>=a2&&a2>=d2){
        cout<<"Genap terbesar			: "<<c2<<b2<<a2<<d2<<endl;
        }
        else if(d2>=b2&&b2>=c2&&c2>=a2){
        cout<<"Genap terbesar			: "<<d2<<b2<<c2<<a2<<endl;
        }
        else if(a2>=c2&&c2>=b2&&b2>=d2){
        cout<<"Genap terbesar			: "<<a2<<c2<<b2<<d2<<endl;
        }
        else if(a2>=d2&&d2>=c2&&c2>=b2){
        cout<<"Genap terbesar			: "<<a2<<d2<<c2<<b2<<endl;
        }
        else if(a2>=b2&&b2>=d2&&d2>=c2){
        cout<<"Genap terbesar			: "<<a2<<b2<<d2<<c2<<endl;
        }
        else if(b2>=c2&&c2>=a2&&a2>=d2){
        cout<<"Genap terbesar			: "<<b2<<c2<<a2<<d2<<endl;
        }
        else if(c2>=a2&&a2>=b2&&b2>=d2){
        cout<<"Genap terbesar			: "<<c2<<a2<<b2<<d2<<endl;
        }
        else if(c2>=a2&&a2>=b2&&b2>=d2){
        cout<<"Genap terbesar			: "<<c2<<b2<<d2<<a2<<endl;
        }
        else if(d2>=a2&&a2>=c2&&c2>=b2){
        cout<<"Genap terbesar			: "<<d2<<a2<<c2<<b2<<endl;
        }
        else if(c2>=a2&&a2>=b2&&b2>=d2){
        cout<<"Genap terbesar			: "<<c2<<b2<<d2<<a2<<endl;
        }
        else if(d2>=c2&&c2>=b2&&b2>=a2){
        if(a2%2==0){
        cout<<"Genap terbesar			: "<<d2<<c2<<b2<<a2<<endl;
        }else if(b2%2==0){
        cout<<"Genap terbesar			: "<<d2<<c2<<a2<<b2<<endl;
        }else if(c2%2==0){
        cout<<"Genap terbesar			: "<<d2<<b2<<a2<<c2<<endl;
        }else{
        cout<<"Genap terbesar			: "<<c2<<b2<<a2<<d2<<endl;
        }
        }
        else if(a2>=c2&&c2>=d2&&d2>=b2){
        cout<<"Genap terbesar			: "<<a2<<c2<<d2<<b2<<endl;
        }
        else if(a2>=d2&&d2>=b2&&b2>=c2){
        cout<<"Genap terbesar			: "<<a2<<d2<<b2<<c2<<endl;
        }
        else if(b2>=a2&&a2>=d2&&d2>=c2){
        cout<<"Genap terbesar			: "<<b2<<a2<<d2<<c2<<endl;
        }
        else if(b2>=d2&&d2>=a2&&a2>=c2){
        cout<<"Genap terbesar			: "<<b2<<d2<<a2<<c2<<endl;
        }
        else if(b2>=d2&&d2>=c2&&c2>=a2){
        cout<<"Genap terbesar			: "<<b2<<d2<<c2<<a2<<endl;
        }
        else if(c2>=a2&&a2>=d2&&d2>=b2){
        cout<<"Genap terbesar			: "<<c2<<a2<<d2<<b2<<endl;
        }
        else if(c2>=d2&&d2>=b2&&b2>=a2){
        cout<<"Genap terbesar			: "<<c2<<d2<<b2<<a2<<endl;
        }
        else if(d2>=b2&&b2>=a2&&a2>=c2){
        cout<<"Genap terbesar			: "<<d2<<b2<<a2<<c2<<endl;
        }
        else if(d2>=c2&&c2>=a2&&a2>=b2){
        cout<<"Genap terbesar			: "<<d2<<c2<<a2<<b2<<endl;
        }}
        else if(a2%2==1||b2%2==1||c2%2==1||d2%2==1){
        cout<<"Genap terbesar			: tidak ada"<<endl;
        }
        if(a3==b3&&a3==c3&&a3==d3||b3==a3&&b3==c3&&b3==d3||c3==a3&&c3==b3&&c3==d3||d3==a3&&d3==b3&&d3==c3)
        {
        cout<<"Palindrom terbesar		: "<<a3<<b3<<c3<<d3<<endl;
        }
        else if(a3==b3&&c3==d3&&a3>c3){
        cout<<"Palindrom terbesar		: "<<a3<<c3<<c3<<a3<<endl;
        }
        else if(a3==b3&&c3==d3&&a3<c3){
        cout<<"Palindrom terbesar		: "<<c3<<a3<<a3<<c3<<endl;
        }
        else if(a3==c3&&b3==d3&&a3>b3){
        cout<<"Palindrom terbesar		: "<<a3<<b3<<b3<<a3<<endl;
        }
        else if(a3==c3&&b3==d3&&a3<b3){
        cout<<"Palindrom terbesar		: "<<b3<<a3<<a3<<b3<<endl;
        }
        else{
        cout<<"Palindrom terbesar		: tidak ada"<<endl;
        }
        if(a4>=b4&&b4>=c4&&c4>=d4){
        cout<<"Bilangan terbesar		: "<<a4<<b4<<c4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=c4&&c4>=d4&&d4>=a4){
        cout<<"Bilangan terbesar		: "<<b4<<c4<<d4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=d4&&d4>=a4&&a4>=b4){
        cout<<"Bilangan terbesar		: "<<c4<<d4<<a4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=a4&&a4>=b4&&b4>=c4){
        cout<<"Bilangan terbesar		: "<<d4<<a4<<b4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=a4&&a4>=c4&&c4>=d4){
        cout<<"Bilangan terbesar		: "<<b4<<a4<<c4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=b4&&b4>=a4&&a4>=d4){
        cout<<"Bilangan terbesar		: "<<c4<<b4<<a4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=b4&&b4>=c4&&c4>=a4){
        cout<<"Bilangan terbesar		: "<<d4<<b4<<c4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=c4&&c4>=b4&&b4>=d4){
        cout<<"Bilangan terbesar		: "<<a4<<c4<<b4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=d4&&d4>=c4&&c4>=b4){
        cout<<"Bilangan terbesar		: "<<a4<<d4<<c4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=b4&b4>=d4&&d4>=c4){
        cout<<"Bilangan terbesar		: "<<a4<<b4<<d4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=c4&&c4>=a4&&a4>=d4){
        cout<<"Bilangan terbesar		: "<<b4<<c4<<a4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=a4&&a4>=b4&&b4>=d4){
        cout<<"Bilangan terbesar		: "<<c4<<a4<<b4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=a4&&a4>=b4&&b4>=d4){
        cout<<"Bilangan terbesar		: "<<c4<<b4<<d4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=a4&&a4>=c4&&c4>=b4){
        cout<<"Bilangan terbesar		: "<<d4<<a4<<c4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=a4&&a4>=b4&&b4>=d4){
        cout<<"Bilangan terbesar		: "<<c4<<b4<<d4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=c4&&c4>=b4&&b4>=a4){
        cout<<"Bilangan terbesar		: "<<d4<<c4<<b4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=c4&c4>=d4&&d4>=b4){
        cout<<"Bilangan terbesar		: "<<a4<<c4<<d4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=d4&&d4>=b4&&b4>=c4){
        cout<<"Bilangan terbesar		: "<<a4<<d4<<b4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=a4&&a4>=d4&&d4>=c4){
        cout<<"Bilangan terbesar		: "<<b4<<a4<<d4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=d4&&d4>=a4&&a4>=c4){
        cout<<"Bilangan terbesar		: "<<b4<<d4<<a4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=d4&&d4>=c4&&c4>=a4){
        cout<<"Bilangan terbesar		: "<<b4<<d4<<c4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=a4&&a4>=d4&d4>=b4){
        cout<<"Bilangan terbesar		: "<<c4<<a4<<d4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=d4&&d4>=b4&&b4>=a4){
        cout<<"Bilangan terbesar		: "<<c4<<d4<<b4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=b4&&b4>=a4&&a4>=c4){
        cout<<"Bilangan terbesar		: "<<d4<<b4<<a4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=c4&&c4>=a4&&a4>=b4){
        cout<<"Bilangan terbesar		: "<<d4<<c4<<a4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        }
	if(c==2)
    {
		srand(time(NULL));
		int input=rand()%7999+999;
		cout<<""<<endl;
		cout<<"Random angka: "<<input<<endl;
		cout<<""<<endl;
		int a,b,c,d;
		int a1,b1,c1,d1;
		int a2,b2,c2,d2;
		int a3,b3,c3,d3;
		int a4,b4,c4,d4;
		a=input/1000;
		b=input/100%10;
		c=input/10%10;
		d=input%10;
        a1=a;
        b1=b;
        c1=c;
        d1=d;
        a2=a;
        b2=b;
        c2=c;
        d2=d;
        a3=a;
        b3=b;
        c3=c;
        d3=d;
        a4=a;
        b4=b;
        c4=c;
        d4=d;
        cout<<"==== Hasil ===="<<endl;
    if(a1%2==1||b1%2==1||c1%2==1||d1%2==1)
        {
        if(a1>=b1&&b1>=c1&&c1>=d1){
        if(d1%2==1){
        cout<<"Ganjil terbesar			: "<<a1<<b1<<c1<<d1<<endl;
        }else if(c1%2==1){
        cout<<"Ganjil terbesar			: "<<a1<<b1<<d1<<c1<<endl;
        }else if(b1%2==1){
        cout<<"Ganjil terbesar			: "<<a1<<d1<<c1<<b1<<endl;
        }else{
        cout<<"Ganjil terbesar			: "<<b1<<d1<<c1<<a1<<endl;
        }
        }
        else if(b1>=c1&&c1>=d1&&d1>=a1){
        cout<<"Ganjil terbesar			: "<<b1<<c1<<d1<<a1<<endl;
        }
        else if(c1>=d1&&d1>=a1&&a1>=b1){
        cout<<"Ganjil terbesar			: "<<c1<<d1<<a1<<b1<<endl;
        }
        else if(d1>=a1&&a1>=b1&&b1>=c1){
        cout<<"Ganjil terbesar			: "<<d1<<a1<<b1<<c1<<endl;
        }
        else if(b1>=a1&&a1>=c1&&c1>=d1){
        cout<<"Ganjil terbesar			: "<<b1<<a1<<c1<<d1<<endl;
        }
        else if(c1>=b1&&b1>=a1&&a1>=d1){
        cout<<"Ganjil terbesar			: "<<c1<<b1<<a1<<d1<<endl;
        }
        else if(d1>=b1&&b1>=c1&&c1>=a1){
        cout<<"Ganjil terbesar			: "<<d1<<b1<<c1<<a1<<endl;
        }
        else if(a1>=c1&&c1>=b1&&b1>=d1){
        cout<<"Ganjil terbesar			: "<<a1<<c1<<b1<<d1<<endl;
        }
        else if(a1>=d1&&d1>=c1&&c1>=b1){
        cout<<"Ganjil terbesar			: "<<a1<<d1<<c1<<b1<<endl;
        }
        else if(a1>=b1&&b1>=d1&&d1>=c1){
        cout<<"Ganjil terbesar			: "<<a1<<b1<<d1<<c1<<endl;
        }
        else if(b1>=c1&&c1>=a1&&a1>=d1){
        cout<<"Ganjil terbesar			: "<<b1<<c1<<a1<<d1<<endl;
        }
        else if(c1>=a1&&a1>=b1&&b1>=d1){
        cout<<"Ganjil terbesar			: "<<c1<<a1<<b1<<d1<<endl;
        }
        else if(c1>=a1&&a1>=b1&&b1>=d1){
        cout<<"Ganjil terbesar			: "<<c1<<b1<<d1<<a1<<endl;
        }
        else if(d1>=a1&&a1>=c1&&c1>=b1){
        cout<<"Ganjil terbesar			: "<<d1<<a1<<c1<<b1<<endl;
        }
        else if(c1>=a1&&a1>=b1&&b1>=d1){
        cout<<"Ganjil terbesar			: "<<c1<<b1<<d1<<a1<<endl;
        }
        else if(d1>=c1&&c1>=b1&&b1>=a1){
        if(a1%2==1){
        cout<<"Ganjil terbesar			: "<<d1<<c1<<b1<<a1<<endl;
        }else if(b1%2==1){
        cout<<"Ganjil terbesar			: "<<d1<<c1<<a1<<b1<<endl;
        }else if(c1%2==1){
        cout<<"Ganjil terbesar			: "<<d1<<a1<<b1<<c1<<endl;
        }else{
        cout<<"Ganjil terbesar			: "<<c1<<a1<<b1<<d1<<endl;
        }
        }
        else if(a1>=c1&&c1>=d1&&d1>=b1){
        cout<<"Ganjil terbesar			: "<<a1<<c1<<d1<<b1<<endl;
        }
        else if(a1>=d1&&d1>=b1&&b1>=c1){
        cout<<"Ganjil terbesar			: "<<a1<<d1<<b1<<c1<<endl;
        }
        else if(b1>=a1&&a1>=d1&&d1>=c1){
        cout<<"Ganjil terbesar			: "<<b1<<a1<<d1<<c1<<endl;
        }
        else if(b1>=d1&&d1>=a1&&a1>=c1){
        cout<<"Ganjil terbesar			: "<<b1<<d1<<a1<<c1<<endl;
        }
        else if(b1>=d1&&d1>=c1&&c1>=a1){
        cout<<"Ganjil terbesar			: "<<b1<<d1<<c1<<a1<<endl;
        }
        else if(c1>=a1&&a1>=d1&&d1>=b1){
        cout<<"Ganjil terbesar			: "<<c1<<a1<<d1<<b1<<endl;
        }
        else if(c1>=d1&&d1>=b1&&b1>=a1){
        cout<<"Ganjil terbesar			: "<<c1<<d1<<b1<<a1<<endl;
        }
        else if(d1>=b1&&b1>=a1&&a1>=c1){
        cout<<"Ganjil terbesar			: "<<d1<<b1<<a1<<c1<<endl;
        }
        else if(d1>=c1&&c1>=a1&&a1>=b1){
        cout<<"Ganjil terbesar			: "<<d1<<c1<<a1<<b1<<endl;
        }
        }
        else if(a1%2==0||b1%2==0||c1%2==0||d1%2==0){
        cout<<"Ganjil terbesar			: tidak ada"<<endl;
        }
        if(a2%2==0||b2%2==0||c2%2==0||d2%2==0)
        {
        if(a2>=b2&&b2>=c2&&c2>=d2){
        if(d2%2==0){
        cout<<"Genap terbesar			: "<<a2<<b2<<c2<<d2<<endl;
        }else if(c2%2==0){
        cout<<"Genap terbesar			: "<<a2<<b2<<d2<<c2<<endl;
        }else if(b2%2==0){
        cout<<"Genap terbesar			: "<<a2<<d2<<c2<<b2<<endl;
        }else{
        cout<<"Genap terbesar			: "<<b2<<d2<<c2<<a2<<endl;
        }
        }
        else if(b2>=c2&&c2>=d2&&d2>=a2){
        cout<<"Genap terbesar			: "<<b2<<c2<<d2<<a2<<endl;
        }
        else if(c2>=d2&&d2>=a2&&a2>=b2){
        cout<<"Genap terbesar			: "<<c2<<d2<<a2<<b2<<endl;
        }
        else if(d2>=a2&&a2>=b2&&b2>=c2){
        cout<<"Genap terbesar			: "<<d2<<a2<<b2<<c2<<endl;
        }
        else if(b2>=a2&&a2>=c2&&c2>=d2){
        cout<<"Genap terbesar			: "<<b2<<a2<<c2<<d2<<endl;
        }
        else if(c2>=b2&&b2>=a2&&a2>=d2){
        cout<<"Genap terbesar			: "<<c2<<b2<<a2<<d2<<endl;
        }
        else if(d2>=b2&&b2>=c2&&c2>=a2){
        cout<<"Genap terbesar			: "<<d2<<b2<<c2<<a2<<endl;
        }
        else if(a2>=c2&&c2>=b2&&b2>=d2){
        cout<<"Genap terbesar			: "<<a2<<c2<<b2<<d2<<endl;
        }
        else if(a2>=d2&&d2>=c2&&c2>=b2){
        cout<<"Genap terbesar			: "<<a2<<d2<<c2<<b2<<endl;
        }
        else if(a2>=b2&&b2>=d2&&d2>=c2){
        cout<<"Genap terbesar			: "<<a2<<b2<<d2<<c2<<endl;
        }
        else if(b2>=c2&&c2>=a2&&a2>=d2){
        cout<<"Genap terbesar			: "<<b2<<c2<<a2<<d2<<endl;
        }
        else if(c2>=a2&&a2>=b2&&b2>=d2){
        cout<<"Genap terbesar			: "<<c2<<a2<<b2<<d2<<endl;
        }
        else if(c2>=a2&&a2>=b2&&b2>=d2){
        cout<<"Genap terbesar			: "<<c2<<b2<<d2<<a2<<endl;
        }
        else if(d2>=a2&&a2>=c2&&c2>=b2){
        cout<<"Genap terbesar			: "<<d2<<a2<<c2<<b2<<endl;
        }
        else if(c2>=a2&&a2>=b2&&b2>=d2){
        cout<<"Genap terbesar			: "<<c2<<b2<<d2<<a2<<endl;
        }
        else if(d2>=c2&&c2>=b2&&b2>=a2){
        if(a2%2==0){
        cout<<"Genap terbesar			: "<<d2<<c2<<b2<<a2<<endl;
        }else if(b2%2==0){
        cout<<"Genap terbesar			: "<<d2<<c2<<a2<<b2<<endl;
        }else if(c2%2==0){
        cout<<"Genap terbesar			: "<<d2<<b2<<a2<<c2<<endl;
        }else{
        cout<<"Genap terbesar			: "<<c2<<b2<<a2<<d2<<endl;
        }
        }
        else if(a2>=c2&&c2>=d2&&d2>=b2){
        cout<<"Genap terbesar			: "<<a2<<c2<<d2<<b2<<endl;
        }
        else if(a2>=d2&&d2>=b2&&b2>=c2){
        cout<<"Genap terbesar			: "<<a2<<d2<<b2<<c2<<endl;
        }
        else if(b2>=a2&&a2>=d2&&d2>=c2){
        cout<<"Genap terbesar			: "<<b2<<a2<<d2<<c2<<endl;
        }
        else if(b2>=d2&&d2>=a2&&a2>=c2){
        cout<<"Genap terbesar			: "<<b2<<d2<<a2<<c2<<endl;
        }
        else if(b2>=d2&&d2>=c2&&c2>=a2){
        cout<<"Genap terbesar			: "<<b2<<d2<<c2<<a2<<endl;
        }
        else if(c2>=a2&&a2>=d2&&d2>=b2){
        cout<<"Genap terbesar			: "<<c2<<a2<<d2<<b2<<endl;
        }
        else if(c2>=d2&&d2>=b2&&b2>=a2){
        cout<<"Genap terbesar			: "<<c2<<d2<<b2<<a2<<endl;
        }
        else if(d2>=b2&&b2>=a2&&a2>=c2){
        cout<<"Genap terbesar			: "<<d2<<b2<<a2<<c2<<endl;
        }
        else if(d2>=c2&&c2>=a2&&a2>=b2){
        cout<<"Genap terbesar			: "<<d2<<c2<<a2<<b2<<endl;
        }}
        else if(a2%2==1||b2%2==1||c2%2==1||d2%2==1){
        cout<<"Genap terbesar			: tidak ada"<<endl;
        }
        if(a3==b3&&a3==c3&&a3==d3||b3==a3&&b3==c3&&b3==d3||c3==a3&&c3==b3&&c3==d3||d3==a3&&d3==b3&&d3==c3)
        {
        cout<<"Palindrom terbesar		: "<<a3<<b3<<c3<<d3<<endl;
        }
        else if(a3==b3&&c3==d3&&a3>c3){
        cout<<"Palindrom terbesar		: "<<a3<<c3<<c3<<a3<<endl;
        }
        else if(a3==b3&&c3==d3&&a3<c3){
        cout<<"Palindrom terbesar		: "<<c3<<a3<<a3<<c3<<endl;
        }
        else if(a3==c3&&b3==d3&&a3>b3){
        cout<<"Palindrom terbesar		: "<<a3<<b3<<b3<<a3<<endl;
        }
        else if(a3==c3&&b3==d3&&a3<b3){
        cout<<"Palindrom terbesar		: "<<b3<<a3<<a3<<b3<<endl;
        }
        else{
        cout<<"Palindrom terbesar		: tidak ada"<<endl;
        }
        if(a4>=b4&&b4>=c4&&c4>=d4){
        cout<<"Bilangan terbesar		: "<<a4<<b4<<c4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=c4&&c4>=d4&&d4>=a4){
        cout<<"Bilangan terbesar		: "<<b4<<c4<<d4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=d4&&d4>=a4&&a4>=b4){
        cout<<"Bilangan terbesar		: "<<c4<<d4<<a4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=a4&&a4>=b4&&b4>=c4){
        cout<<"Bilangan terbesar		: "<<d4<<a4<<b4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=a4&&a4>=c4&&c4>=d4){
        cout<<"Bilangan terbesar		: "<<b4<<a4<<c4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=b4&&b4>=a4&&a4>=d4){
        cout<<"Bilangan terbesar		: "<<c4<<b4<<a4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=b4&&b4>=c4&&c4>=a4){
        cout<<"Bilangan terbesar		: "<<d4<<b4<<c4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=c4&&c4>=b4&&b4>=d4){
        cout<<"Bilangan terbesar		: "<<a4<<c4<<b4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=d4&&d4>=c4&&c4>=b4){
        cout<<"Bilangan terbesar		: "<<a4<<d4<<c4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=b4&b4>=d4&&d4>=c4){
        cout<<"Bilangan terbesar		: "<<a4<<b4<<d4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=c4&&c4>=a4&&a4>=d4){
        cout<<"Bilangan terbesar		: "<<b4<<c4<<a4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=a4&&a4>=b4&&b4>=d4){
        cout<<"Bilangan terbesar		: "<<c4<<a4<<b4<<d4;
        if(d4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=a4&&a4>=b4&&b4>=d4){
        cout<<"Bilangan terbesar		: "<<c4<<b4<<d4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=a4&&a4>=c4&&c4>=b4){
        cout<<"Bilangan terbesar		: "<<d4<<a4<<c4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=a4&&a4>=b4&&b4>=d4){
        cout<<"Bilangan terbesar		: "<<c4<<b4<<d4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=c4&&c4>=b4&&b4>=a4){
        cout<<"Bilangan terbesar		: "<<d4<<c4<<b4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=c4&c4>=d4&&d4>=b4){
        cout<<"Bilangan terbesar		: "<<a4<<c4<<d4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(a4>=d4&&d4>=b4&&b4>=c4){
        cout<<"Bilangan terbesar		: "<<a4<<d4<<b4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=a4&&a4>=d4&&d4>=c4){
        cout<<"Bilangan terbesar		: "<<b4<<a4<<d4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=d4&&d4>=a4&&a4>=c4){
        cout<<"Bilangan terbesar		: "<<b4<<d4<<a4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(b4>=d4&&d4>=c4&&c4>=a4){
        cout<<"Bilangan terbesar		: "<<b4<<d4<<c4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=a4&&a4>=d4&d4>=b4){
        cout<<"Bilangan terbesar		: "<<c4<<a4<<d4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(c4>=d4&&d4>=b4&&b4>=a4){
        cout<<"Bilangan terbesar		: "<<c4<<d4<<b4<<a4;
        if(a4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=b4&&b4>=a4&&a4>=c4){
        cout<<"Bilangan terbesar		: "<<d4<<b4<<a4<<c4;
        if(c4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        else if(d4>=c4&&c4>=a4&&a4>=b4){
        cout<<"Bilangan terbesar		: "<<d4<<c4<<a4<<b4;
        if(b4%2==0)
        {
        cout<<" (genap)";
        }
        else{cout<<" (ganjil)";}
        }
        }
}
