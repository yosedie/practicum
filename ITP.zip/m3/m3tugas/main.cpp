#include<iostream>
#include<ctime>
#include<cmath>
#include<conio.h>
using namespace std;
int main()
{
    int inp=0;
    bool cek=true;
    do{
        int inp;
        cout<<"1. Ganjil Genap"<<endl;
        cout<<"2. Cetak Papan Catur"<<endl;
        cout<<"0. Exit"<<endl;
        cout<<">> ";
        cin>>inp;
        cout<<endl;
        if(inp==1){
        srand(time(0));
        int pi,com1,com2,com3,p1,p2,p3,a1,a2,a3,a4=0,a5=0,a6=0,a7=0;
        int b2,b3,b4=0,b5=0,b6=0,b7=0,c2,c3,c4=0,c5=0,c6=0,c7=0;
        com1=(rand()%10)+1;
        com2=(rand()%10)+1;
        com3=(rand()%10)+1;
        cout<<"=== Ganjil Genap ==="<<endl;
        cout<<"Jumlah pemain : ";
        cin>>pi;
        cout<<endl;
            if(pi==1){
            cout<<"Pilih ganjil atau genap"<<endl;
            cout<<"pemain 1 : ";
            cin>>p1;
            cout<<endl;
                if(p1==1){
                    cout<<"== Round 1 =="<<endl;
                    cout<<"pemain 1"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com1<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<"input angka : "<<a2<<endl;
                        cout<<endl;
                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com1<<endl;
                        a3=com1+a2;
                        cout<<"pemain 1 (ganjil) : "<<a2<<" ("<<com1<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;
                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a4=a4+0;
                                }else{a4=a4+1;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a4<<endl;
                                cout<<endl;
                    cout<<"== Round 2 =="<<endl;
                    cout<<"pemain 1"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com2<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<"input angka : "<<a2<<endl;
                        cout<<endl;
                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com2<<endl;
                        a3=com2+a2;
                        cout<<"pemain 1 (ganjil) : "<<a2<<" ("<<com2<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                                cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;
                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a5=a5+0;
                                }else{a5=a5+1;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a5<<endl;
                                cout<<endl;
                        cout<<"== Round 3 =="<<endl;
                    cout<<"pemain 1"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com3<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<"input angka : "<<a2<<endl;
                        cout<<endl;
                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com3<<endl;
                        a3=com3+a2;
                        cout<<"pemain 1 (ganjil) : "<<a2<<" ("<<com3<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                                cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;
                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a6=a6+0;
                                }else{a6=a6+1;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a6<<endl;
                                cout<<endl;
                                    cout<<"== Final Score =="<<endl;
                                    cout<<"Pemain 1 : "<<a4+a5+a6<<endl;
                                    cout<<endl;
                        }
                        }
                        }
                }else if(p1==2){
                    cout<<"== Round 1 =="<<endl;
                    cout<<"pemain 1"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com1<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<"input angka : "<<a2<<endl;
                        cout<<endl;
                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com1<<endl;
                        a3=com1+a2;
                        cout<<"pemain 1 (genap) : "<<a2<<" ("<<com1<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;
                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a4=a4+1;
                                }else{a4=a4+0;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a4<<endl;
                                cout<<endl;
                    cout<<"== Round 2 =="<<endl;
                    cout<<"pemain 1"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com2<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<"input angka : "<<a2<<endl;
                        cout<<endl;
                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com2<<endl;
                        a3=com2+a2;
                        cout<<"pemain 1 (genap) : "<<a2<<" ("<<com2<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                                cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;
                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a5=a5+1;
                                }else{a5=a5+0;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a5<<endl;
                                cout<<endl;
                        cout<<"== Round 3 =="<<endl;
                    cout<<"pemain 1"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com3<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<"input angka : "<<a2<<endl;
                        cout<<endl;
                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com3<<endl;
                        a3=com3+a2;
                        cout<<"pemain 1 (genap) : "<<a2<<" ("<<com3<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                                cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;
                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a6=a6+1;
                                }else{a6=a6+0;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a6<<endl;
                                cout<<endl;
                                    cout<<"== Final Score =="<<endl;
                                    cout<<"Pemain 1 : "<<a4+a5+a6<<endl;
                                    cout<<endl;
                        }
                        }
                        }
                }
            }else if(pi==2){
            cout<<"Pilih ganjil atau genap"<<endl;
            cout<<"pemain 1 : ";
            cin>>p1;
            cout<<"pemain 2 : ";
            cin>>p2;
            cout<<endl;
                if(p1==1){
                    cout<<"== Round 1 =="<<endl;
                    cout<<"pemain 1 (ganjil)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com1<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (genap)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com1<<endl;
                        a3=com1+a2;
                        b3=com1+b2;

                        cout<<"pemain 1 (ganjil) : "<<a2<<" ("<<com1<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                        cout<<"pemain 2 (genap) : "<<b2<<" ("<<com1<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a4=a4+0;
                                }else{a4=a4+1;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a4<<endl;

                                if(b3%2==0){
                                b4=b4+1;
                                }else{b4=b4+0;}
                                cout<<"Pemain 2 : "<<b4<<endl;

                                cout<<endl;
                    cout<<"== Round 2 =="<<endl;
                    cout<<"pemain 1 (ganjil)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com2<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (genap)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com2<<endl;
                        a3=com2+a2;
                        b3=com2+b2;

                        cout<<"pemain 1 (ganjil) : "<<a2<<" ("<<com2<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                        cout<<"pemain 2 (genap) : "<<b2<<" ("<<com2<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a5=a5+0;
                                }else{a5=a5+1;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a5<<endl;

                                if(b3%2==0){
                                b5=b5+1;
                                }else{b5=b5+0;}
                                cout<<"Pemain 2 : "<<b5<<endl;

                                cout<<endl;
                        cout<<"== Round 3 =="<<endl;
                    cout<<"pemain 1 (ganjil)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com3<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (genap)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com3<<endl;
                        a3=com3+a2;
                        b3=com3+b2;

                        cout<<"pemain 1 (ganjil) : "<<a2<<" ("<<com3<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                        cout<<"pemain 2 (genap) : "<<b2<<" ("<<com3<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a6=a6+0;
                                }else{a6=a6+1;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a6<<endl;

                                if(b3%2==0){
                                b6=b6+1;
                                }else{b6=b6+0;}
                                cout<<"Pemain 2 : "<<b6<<endl;

                                cout<<endl;
                                    cout<<"== Final Score =="<<endl;
                                    cout<<"Pemain 1 : "<<a4+a5+a6<<endl;
                                    cout<<"Pemain 2 : "<<b4+b5+b6<<endl;
                                    cout<<endl;
                        }
                        }
                        }
                }else if(p1==2){
                    cout<<"== Round 1 =="<<endl;
                    cout<<"pemain 1 (genap)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com1<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (ganjil)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com1<<endl;
                        a3=com1+a2;
                        b3=com1+b2;

                        cout<<"pemain 1 (genap) : "<<a2<<" ("<<com1<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                        cout<<"pemain 2 (ganjil) : "<<b2<<" ("<<com1<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"0";
                            }else{cout<<"1";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a4=a4+1;
                                }else{a4=a4+0;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a4<<endl;

                                if(b3%2==0){
                                b4=b4+0;
                                }else{b4=b4+1;}
                                cout<<"Pemain 2 : "<<b4<<endl;

                                cout<<endl;
                    cout<<"== Round 2 =="<<endl;
                    cout<<"pemain 1 (genap)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com2<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (ganjil)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com2<<endl;
                        a3=com2+a2;
                        b3=com2+b2;

                        cout<<"pemain 1 (genap) : "<<a2<<" ("<<com2<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                        cout<<"pemain 2 (ganjil) : "<<b2<<" ("<<com2<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a5=a5+1;
                                }else{a5=a5+0;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a5<<endl;

                                if(b3%2==0){
                                b5=b5+0;
                                }else{b5=b5+1;}
                                cout<<"Pemain 2 : "<<b5<<endl;

                                cout<<endl;
                        cout<<"== Round 3 =="<<endl;
                    cout<<"pemain 1 (genap)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com3<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (ganjil)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com3<<endl;
                        a3=com3+a2;
                        b3=com3+b2;

                        cout<<"pemain 1 (genap) : "<<a2<<" ("<<com3<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                        cout<<"pemain 2 (ganjil) : "<<b2<<" ("<<com3<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a6=a6+1;
                                }else{a6=a6+0;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a6<<endl;

                                if(b3%2==0){
                                b6=b6+0;
                                }else{b6=b6+1;}
                                cout<<"Pemain 2 : "<<b6<<endl;

                                cout<<endl;
                                    cout<<"== Final Score =="<<endl;
                                    cout<<"Pemain 1 : "<<a4+a5+a6<<endl;
                                    cout<<"Pemain 2 : "<<b4+b5+b6<<endl;
                                    cout<<endl;
                        }
                        }
                        }
                }

            }else if(pi==3){
            cout<<"Pilih ganjil atau genap"<<endl;
            cout<<"pemain 1 : ";
            cin>>p1;
            cout<<"pemain 2 : ";
            cin>>p2;
            cout<<"pemain 3 : ";
            cin>>p3;
            cout<<endl;
                if(p1==1){
                    cout<<"== Round 1 =="<<endl;
                    cout<<"pemain 1 (ganjil)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com1<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (genap)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"pemain 3 (ganjil)"<<endl;
                        cout<<"input angka : ";
                        cin>>c2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com1<<endl;
                        a3=com1+a2;
                        b3=com1+b2;
                        c3=com1+c2;

                        cout<<"pemain 1 (ganjil) : "<<a2<<" ("<<com1<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                        cout<<"pemain 2 (genap) : "<<b2<<" ("<<com1<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                        cout<<"pemain 3 (ganjil) : "<<c2<<" ("<<com1<<" + "<<c2<<" = "<<c3<<") -> ";
                            if(c3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a4=a4+0;
                                }else{a4=a4+1;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a4<<endl;

                                if(b3%2==0){
                                b4=b4+1;
                                }else{b4=b4+0;}
                                cout<<"Pemain 2 : "<<b4<<endl;

                                if(c3%2==0){
                                c4=c4+0;
                                }else{c4=c4+1;}
                                cout<<"Pemain 3 : "<<c4<<endl;

                                cout<<endl;
                    cout<<"== Round 2 =="<<endl;
                    cout<<"pemain 1 (ganjil)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com2<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (genap)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"pemain 3 (ganjil)"<<endl;
                        cout<<"input angka : ";
                        cin>>c2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com2<<endl;
                        a3=com2+a2;
                        b3=com2+b2;
                        c3=com2+c2;

                        cout<<"pemain 1 (ganjil) : "<<a2<<" ("<<com2<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                        cout<<"pemain 2 (genap) : "<<b2<<" ("<<com2<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                        cout<<"pemain 3 (ganjil) : "<<c2<<" ("<<com2<<" + "<<c2<<" = "<<c3<<") -> ";
                            if(c3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a5=a5+0;
                                }else{a5=a5+1;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a5<<endl;

                                if(b3%2==0){
                                b5=b5+1;
                                }else{b5=b5+0;}
                                cout<<"Pemain 2 : "<<b5<<endl;

                                if(c3%2==0){
                                c5=c5+0;
                                }else{c5=c5+1;}
                                cout<<"Pemain 3 : "<<c5<<endl;

                                cout<<endl;
                        cout<<"== Round 3 =="<<endl;
                    cout<<"pemain 1 (ganjil)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com3<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (genap)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"pemain 3 (ganjil)"<<endl;
                        cout<<"input angka : ";
                        cin>>c2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com3<<endl;
                        a3=com3+a2;
                        b3=com3+b2;
                        c3=com3+c2;

                        cout<<"pemain 1 (ganjil) : "<<a2<<" ("<<com3<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                        cout<<"pemain 2 (genap) : "<<b2<<" ("<<com3<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                        cout<<"pemain 3 (ganjil) : "<<c2<<" ("<<com3<<" + "<<c2<<" = "<<c3<<") -> ";
                            if(c3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a6=a6+0;
                                }else{a6=a6+1;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a6<<endl;

                                if(b3%2==0){
                                b6=b6+1;
                                }else{b6=b6+0;}
                                cout<<"Pemain 2 : "<<b6<<endl;

                                if(c3%2==0){
                                c6=c6+0;
                                }else{c6=c6+1;}
                                cout<<"Pemain 3 : "<<c6<<endl;

                                cout<<endl;
                                    cout<<"== Final Score =="<<endl;
                                    cout<<"Pemain 1 : "<<a4+a5+a6<<endl;
                                    cout<<"Pemain 2 : "<<b4+b5+b6<<endl;
                                    cout<<"Pemain 3 : "<<c4+c5+c6<<endl;
                                    cout<<endl;
                        }
                        }
                        }
                }else if(p1==2){
                    cout<<"== Round 1 =="<<endl;
                    cout<<"pemain 1 (genap)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com1<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (ganjil)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com1<<endl;
                        a3=com1+a2;
                        b3=com1+b2;

                        cout<<"pemain 1 (genap) : "<<a2<<" ("<<com1<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                        cout<<"pemain 2 (ganjil) : "<<b2<<" ("<<com1<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"0";
                            }else{cout<<"1";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a4=a4+1;
                                }else{a4=a4+0;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a4<<endl;

                                if(b3%2==0){
                                b4=b4+0;
                                }else{b4=b4+1;}
                                cout<<"Pemain 2 : "<<b4<<endl;

                                cout<<endl;
                    cout<<"== Round 2 =="<<endl;
                    cout<<"pemain 1 (genap)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com2<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (ganjil)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com2<<endl;
                        a3=com1+a2;
                        b3=com1+b2;

                        cout<<"pemain 1 (genap) : "<<a2<<" ("<<com2<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                        cout<<"pemain 2 (ganjil) : "<<b2<<" ("<<com2<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a5=a5+1;
                                }else{a5=a5+0;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a5<<endl;

                                if(b3%2==0){
                                b5=b5+0;
                                }else{b5=b5+1;}
                                cout<<"Pemain 2 : "<<b5<<endl;

                                cout<<endl;
                        cout<<"== Round 3 =="<<endl;
                    cout<<"pemain 1 (genap)"<<endl;
                    cout<<"1. intip computer"<<endl;
                    cout<<"2. input angka"<<endl;
                    cout<<">> ";
                    cin>>a1;
                    cout<<endl;
                        if(a1==1){
                        cout<<"computer : "<<com3<<endl;
                        cout<<endl;
                        }else if(a1==2){
                        cout<<"input angka : ";
                        cin>>a2;
                        cout<<endl;

                        cout<<"pemain 2 (ganjil)"<<endl;
                        cout<<"input angka : ";
                        cin>>b2;
                        cout<<endl;

                        cout<<"Reveal angka"<<endl;
                        cout<<"Computer : "<<com3<<endl;
                        a3=com3+a2;
                        b3=com3+b2;

                        cout<<"pemain 1 (genap) : "<<a2<<" ("<<com3<<" + "<<a2<<" = "<<a3<<") -> ";
                            if(a3%2==0){
                            cout<<"+1";
                            }else{cout<<"0";}
                            cout<<endl;

                        cout<<"pemain 2 (ganjil) : "<<b2<<" ("<<com3<<" + "<<b2<<" = "<<b3<<") -> ";
                            if(b3%2==0){
                            cout<<"0";
                            }else{cout<<"+1";}
                            cout<<endl;

                            cout<<endl;
                            cout<<"- Score -"<<endl;
                                if(a3%2==0){
                                a6=a6+1;
                                }else{a6=a6+0;}
                                cout<<endl;
                                cout<<"Pemain 1 : "<<a6<<endl;

                                if(b3%2==0){
                                b6=b6+0;
                                }else{b6=b6+1;}
                                cout<<"Pemain 2 : "<<b6<<endl;

                                cout<<endl;
                                    cout<<"== Final Score =="<<endl;
                                    cout<<"Pemain 1 : "<<a4+a5+a6<<endl;
                                    cout<<"Pemain 2 : "<<b4+b5+b6<<endl;
                                    cout<<endl;
                        }
                        }
                        }
                    }

                }



        }else if(inp==2){
            cek=true;
            cout<<"== Cetak Papan Catur =="<<endl;
            int b,k,t,l;
            cout<<"Baris : ";
            cin>>b;
            cout<<"Kolom : ";
            cin>>k;
            cout<<"Tinggi : ";
            cin>>t;
            cout<<"Lebar : ";
            cin>>l;
            for(int j=1;j<=b*(1+t)+1;j++){
                for(int i=1;i<=k*(1+l)+1;i++){
                    if(i==1||j==1||(j-1)%(1+t)==0||(i-1)%(1+l)==0){
                        cout<<"* ";
                    }else if((j-1)%(1+t)==1&&(i-1)%(1+l)==1){
                    cout<<"# ";
                    }else if((j-1)%(1+t)==2&&(i-1)%(1+l)==2){
                    cout<<"# ";
                    }else if((j-1)%(1+t)==-1&&(i-1)%(1+l)==-1){
                    cout<<" #";
                    }else if((j-1)%(1+t)==-2&&(i-1)%(1+l)==-2){
                    cout<<" #";
                    }else if((j-1)%(1+t)==3&&(i-1)%(1+l)==3){
                    cout<<"# ";
                    }else if((j-1)%(1+t)==4&&(i-1)%(1+l)==4){
                    cout<<"# ";
                    }else if((j-1)%(1+t)==-3&&(i-1)%(1+l)==-3){
                    cout<<" #";
                    }else if((j-1)%(1+t)==-4&&(i-1)%(1+l)==-4){
                    cout<<" #";
                    }
                    else{cout<<" ";}
                }cout<<endl;
            }
        }else if(inp==0){
            cek=false;
        }
    }while(cek);
return 0;
}
