#include<iostream>
#include<fstream>
#include<string>
using namespace std;
int main(){
    bool k=false;
    while(k==false){
    int p,p0;
    char g,d;
    cout<<"=== T7 : Hangman ==="<<endl;
    cout<<"1. Play"<<endl;
    cout<<"2. Input data"<<endl;
    cout<<"3. Save data"<<endl;
    cout<<"4. Load data"<<endl;
    cout<<"0. Exit"<<endl;
    cout<<">> ";
    cin>>p;
    if(p==1){
        bool k0=false;
        while(k0==false){
        cout<<"=== T7 : Hangman ==="<<endl;
        cout<<"Let's Play"<<endl;
        cout<<endl;
        cout<<"G _ _ _ _ G"<<endl;
        cout<<endl;
        cout<<"Huruf yang salah : A J H"<<endl;
        cout<<endl;
        cout<<"1. Guess"<<endl;
        cout<<"2. Seek (Cheat)"<<endl;
        cout<<"3. Back"<<endl;
        cout<<">> ";
        cin>>p0;
        if(p0==1){
                cout<<"Input letter :";
                cin>>g;
                if(g=='G'||g=='g'){cout<<"Huruf benar pada lokasi 1 dan 6"<<endl;
                }else if(g=='G'||g=='g'){cout<<"Huruf sudah ditebak!"<<endl;
                }else if(g=='U'||g=='u'){cout<<"Huruf benar pada lokasi 2 dan 4"<<endl;
                }else if(g=='U'||g=='u'){cout<<"Huruf sudah ditebak!"<<endl;
        cout<<"=== T7 : Hangman ==="<<endl;
        cout<<"Let's Play"<<endl;
        cout<<endl;
        cout<<"G U _ U _ G"<<endl;
        cout<<endl;
        cout<<"Huruf yang salah : A J H"<<endl;
        cout<<endl;
        cout<<"1. Guess"<<endl;
        cout<<"2. Seek (Cheat)"<<endl;
        cout<<"3. Back"<<endl;
        cout<<">> ";
        cin>>p0;
                }else if(g=='N'||g=='n'){cout<<"Huruf benar pada lokasi 3 dan 5"<<endl;
                }else if(g=='N'||g=='n'){cout<<"Huruf sudah ditebak!"<<endl;
        cout<<"=== T7 : Hangman ==="<<endl;
        cout<<"Let's Play"<<endl;
        cout<<endl;
        cout<<"G U N U N G"<<endl;
        cout<<endl;
        cout<<"Huruf yang salah : A J H"<<endl;
        cout<<endl;
        cout<<"1. Guess"<<endl;
        cout<<"2. Seek (Cheat)"<<endl;
        cout<<"3. Back"<<endl;
        cout<<">> ";
        cin>>p0;
                }else{cout<<"Huruf tidak ada dalam kata!"<<endl;}
        }else if(p0==2){
        cout<<"Word : G U N U N G"<<endl;
        }else if(p0==3){
        k0=true;
        }else{cout<<endl;}
    }
    }else if(p==2){
        cout<<"=== T7 : Hangman ==="<<endl;
        cout<<"Input data"<<endl;
        cout<<"List kata yang ada :"<<endl;
        cout<<"1. GUNUNG"<<endl;
        cout<<"2. AKU"<<endl;
        cout<<"3. SUKA"<<endl;
        cout<<"4. KAMU"<<endl;
        cout<<endl;
        cout<<"Word : ";
        cin>>d;
        if(d=='PEGUNUNGAN'||d=='pegunungan'){
            cout<<"Kata tidak sesuai ketentuan!"<<endl;
        }else if(d=='DIA'||d=='dia'){
            cout<<"Kata berhasil ditambahkan!"<<endl;
        }else{cout<<"Kata tidak sesuai ketentuan!"<<endl;}
    }else if(p==3){
        cout<<"Berhasil simpan data dengan total kata sebanyak 4"<<endl;
        ofstream out("222117059_list_kata.txt",ios::trunc);
        if (out.is_open()){
        out<<"1. GUNUNG"<<endl;
        out<<"2. AKU"<<endl;
        out<<"3. SUKA"<<endl;
        out<<"4. KAMU"<<endl;
        out.close();
        }
    }else if(p==4){
        cout<<"Berhasil load data dengan total kata sebanyak 4"<<endl;
        string kalimat;
        string kumpulan[99];
        int idx=0;
        ifstream in("222117059_list_kata.txt");
        if(in.is_open()){
        while(!in.eof()){
            getline(in,kalimat);
            kumpulan[idx]=kalimat;
            idx++;
        }in.close();
        }
        }else if(p==0){
        k=true;
        }else{cout<<endl;}
    }cout<<"Sampai jumpa"<<endl;
    return 0;
}
