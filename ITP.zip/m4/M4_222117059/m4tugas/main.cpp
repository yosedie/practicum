#include<iostream>
#include<windows.h>
#include<conio.h>
#include<time.h>
using namespace std;
int main(){
    int m,s0=0,s1,s2,s3,tiket=0;
    int s,easy=0,medium=0,hard=0;
    int e1,e2,e3,e4,e5;
    int m1,m2,m3,m4,m5,m6,m7,m8,m9,m10;
    int h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15;
    int ipad=0,bon=0,bol=0,ip,bn,bl;
    srand(time(0));
    e1=(rand()%1);e2=(rand()%1);e3=(rand()%1);e4=(rand()%1);e5=(rand()%1);
    m1=(rand()%1);m2=(rand()%1);m3=(rand()%1);m4=(rand()%1);m5=(rand()%1);
    m6=(rand()%1);m7=(rand()%1);m8=(rand()%1);m9=(rand()%1);m10=(rand()%1);
    h11=(rand()%1);h12=(rand()%1);h13=(rand()%1);h14=(rand()%1);h15=(rand()%1);
    h1=(rand()%1);h2=(rand()%1);h3=(rand()%1);h4=(rand()%1);h5=(rand()%1);
    h6=(rand()%1);h7=(rand()%1);h8=(rand()%1);h9=(rand()%1);h10=(rand()%1);
    bool k=false;
    while(k==false){
        cout<<"=== Selamat Datang di Timezone ==="<<endl;
        cout<<"1. Main pump"<<endl;
        cout<<"2. Topup Saldo"<<endl;
        cout<<"3. Lihat Profil"<<endl;
        cout<<"4. Tukar Tiket"<<endl;
        cout<<"0. Exit"<<endl;
        cout<<">> ";
        cin>>m;
        if(m==1){
        cout<<"=== Pump it up ==="<<endl;
        cout<<"1. Easy"<<endl;
        cout<<"2. Medium"<<endl;
        cout<<"3. Hard"<<endl;
        cout<<">> ";
        cin>>s;

        if(s==1){
        bool on=true;
        do{
        system("cls");
        cout<<"tiket : "<<tiket<<endl;
        cout<<endl;
        for(int x=0;x<13;x++){
            for(int y=0;y<8;y++){
                if((x==0&&y==0)||(x==0&&y==7)||
                   (x==12&&y==0)||(x==12&&y==7)){
                    cout<<" ";
                }else if(x==0||x==12){
                    cout<<"-";
                }else if((x==7&&y==0)||(y==7&&x==7)||
                         (x==11&&y==0)||(y==7&&x==11)){
                    cout<<"+";
                }else if(y==0|y==7){
                    cout<<"|";
                }else if(x==1&&y==2){
                    cout<<"0";
                }else if(x==4&&y==6){
                    cout<<"0";
                }else if(x==7&&y==3){
                    cout<<"0";
                }else if(x==10&&y==4){
                    cout<<"0";
                }else{
                    cout<<" ";
                }
            }cout<<endl;
            }cout<<" sdfjkl"<<endl;

            if(kbhit()){
            char moves=getch();
            if(moves=='S'||moves=='s'){
                tiket=tiket+1;easy=easy+1;
            }else if(moves=='D'||moves=='d'){
                tiket=tiket+1;easy=easy+1;
            }else if(moves=='F'||moves=='f'){
                tiket=tiket+1;easy=easy+1;
            }else if(moves=='J'||moves=='j'){
                tiket=tiket+1;easy=easy+1;
            }else if(moves =='K'||moves=='k'){
                tiket=tiket+1;easy=easy+1;
            }else if(moves =='L'||moves=='l'){
                tiket=tiket+1;easy=easy+1;
            }else if(moves>=5){
                on=false;
            }
            }Sleep(100);
        }while(on);
    }if(s==2){
        bool on=true;
        do{
        system("cls");
        cout<<"tiket : "<<tiket<<endl;
        cout<<endl;
        for(int x=0;x<13;x++){
            for(int y=0;y<8;y++){
                if((x==0&&y==0)||(x==0&&y==7)||
                   (x==12&&y==0)||(x==12&&y==7)){
                    cout<<" ";
                }else if(x==0||x==12){
                    cout<<"-";
                }else if((x==7&&y==0)||(y==7&&x==7)||
                         (x==11&&y==0)||(y==7&&x==11)){
                    cout<<"+";
                }else if(y==0|y==7){
                    cout<<"|";
                }else if(x==1&&y==1){
                    cout<<"0";
                }else if(x==3&&y==2){
                    cout<<"0";
                }else if(x==5&&y==4){
                    cout<<"0";
                }else if(x==7&&y==3){
                    cout<<"0";
                }else if(x==9&&y==6){
                    cout<<"0";
                }else{
                    cout<<" ";
                }
            }cout<<endl;
            }cout<<" sdfjkl"<<endl;

            if(kbhit()){
            char moves=getch();
            if(moves=='S'||moves=='s'){
                tiket=tiket+10;medium=medium+10;
            }else if(moves=='D'||moves=='d'){
                tiket=tiket+10;medium=medium+10;
            }else if(moves=='F'||moves=='f'){
                tiket=tiket+10;medium=medium+10;
            }else if(moves=='J'||moves=='j'){
                tiket=tiket+10;medium=medium+10;
            }else if(moves =='K'||moves=='k'){
                tiket=tiket+10;medium=medium+10;
            }else if(moves =='L'||moves=='l'){
                tiket=tiket+10;medium=medium+10;
            }else if(moves>=10){
                on=false;
            }
            }Sleep(100);
        }while(on);
    }if(s==3){
        bool on=true;
        do{
        system("cls");
        cout<<"tiket : "<<tiket<<endl;
        cout<<endl;
        for(int x=0;x<13;x++){
            for(int y=0;y<8;y++){
                if((x==0&&y==0)||(x==0&&y==7)||
                   (x==12&&y==0)||(x==12&&y==7)){
                    cout<<" ";
                }else if(x==0||x==12){
                    cout<<"-";
                }else if((x==7&&y==0)||(y==7&&x==7)||
                         (x==11&&y==0)||(y==7&&x==11)){
                    cout<<"+";
                }else if(y==0|y==7){
                    cout<<"|";
                }else if(x==1&&y==6){
                    cout<<"0";
                }else if(x==2&&y==1){
                    cout<<"0";
                }else if(x==3&&y==2){
                    cout<<"0";
                }else if(x==4&&y==4){
                    cout<<"0";
                }else if(x==5&&y==1){
                    cout<<"0";
                }else if(x==6&&y==6){
                    cout<<"0";
                }else if(x==7&&y==3){
                    cout<<"0";
                }else if(x==8&&y==4){
                    cout<<"0";
                }else{
                    cout<<" ";
                }
            }cout<<endl;
            }cout<<" sdfjkl"<<endl;

            if(kbhit()){
            char moves=getch();
            if(moves=='S'||moves=='s'){
                tiket=tiket+100;hard=hard+100;
            }else if(moves=='D'||moves=='d'){
                tiket=tiket+100;hard=hard+100;
            }else if(moves=='F'||moves=='f'){
                tiket=tiket+100;hard=hard+100;
            }else if(moves=='J'||moves=='j'){
                tiket=tiket+100;hard=hard+100;
            }else if(moves =='K'||moves=='k'){
                tiket=tiket+100;hard=hard+100;
            }else if(moves =='L'||moves=='l'){
                tiket=tiket+100;hard=hard+100;
            }else if(moves>=15){
                on=false;
            }
            }Sleep(100);
        }while(on);
    }


    else{
    cout<<""<<endl;
    }


        }else if(m==2){
            bool k=false;
                cout<<"--- Topup Saldo ---"<<endl;
                cout<<"Saldo sekarang : "<<s0<<endl;
            while(k==false){
                cout<<"Masukkan jumlah topup : ";
                cin>>s1;
                if(s1>=0){
                    s0=s0+s1;
                cout<<"Berhasil topup saldo!"<<endl;
                cout<<"Saldo sekarang : "<<s0<<endl;
                }
                else if(s1==-1){
                    k=true;
                }
                else{
                    cout<<"";
                }
            }
        }else if(m==3){
                cout<<"--- Lihat Profil ---"<<endl;
                cout<<"Total tiket"<<endl;
                cout<<"Easy : "<<easy<<endl;
                cout<<"Medium : "<<medium<<endl;
                cout<<"Hard : "<<hard<<endl;
                cout<<""<<endl;
                cout<<"Saldo : "<<s0<<endl;
                cout<<"Tiket : "<<tiket<<endl;
                cout<<"Perolehan hadiah :"<<endl;
                cout<<"- Ipad : "<<ipad<<endl;
                cout<<"- Boneka : "<<bon<<endl;
                cout<<"- Bolpen : "<<bol<<endl;
                cout<<"Press enter to continue..."<<endl;
                getch();
        }else if(m==4){
            bool k=false;
                cout<<"--- Tukar Tiket ---"<<endl;
                cout<<"Total tiket : "<<tiket<<endl;
            while(k==false){
                cout<<"List Hadiah"<<endl;
                cout<<"1. Ipad (10000 tiket)"<<endl;
                cout<<"2. Boneka (100 tiket)"<<endl;
                cout<<"3. Bolpen (10 tiket)"<<endl;
                cout<<"4. Tambah tiket (cheat)"<<endl;
                cout<<"0. Exit"<<endl;
                cout<<">> ";
                cin>>s2;
                cout<<endl;
                    if(s2==4){
                        cout<<"Masukkan jumlah tiket : ";
                        cin>>s3;
                        tiket=s3+tiket;
                        cout<<"Berhasil menambahkan tiket!"<<endl;
                        cout<<endl;
                        cout<<"Total tiket : "<<tiket<<endl;
                    }else if(s2==3){
                        bool k=false;
                        while(k==false){
                        cout<<"Jumlah Bolpen : ";
                        cin>>bl;
                        if(bl>tiket){
                        cout<<"Tiket tidak mencukupi!"<<endl;
                        k=true;
                        }else{
                        cout<<"Total : "<<bl<<" x 10 = "<<bl*10<<endl;
                        cout<<"Sisa tiket : "<<tiket-(bl*10)<<endl;
                        bol=bol+bl;
                        tiket=tiket-(bl*10);
                        k=true;
                        }
                    }
                    }else if(s2==2){
                        bool k=false;
                        while(k==false){
                        cout<<"Jumlah Boneka : ";
                        cin>>bn;
                        if(bn>tiket){
                        cout<<"Tiket tidak mencukupi!"<<endl;
                        k=true;
                        }else{
                        cout<<"Total : "<<bn<<" x 10 = "<<bn*100<<endl;
                        cout<<"Sisa tiket : "<<tiket-(bn*100)<<endl;
                        bon=bon+bn;
                        tiket=tiket-(bn*100);
                        k=true;
                        }
                    }
                    }else if(s2==1){
                        bool k=false;
                        while(k==false){
                        cout<<"Jumlah Ipad : ";
                        cin>>ip;
                        if(ip>tiket){
                        cout<<"Tiket tidak mencukupi!"<<endl;
                        k=true;
                        }else{
                        cout<<"Total : "<<ip<<" x 10 = "<<ip*10000<<endl;
                        cout<<"Sisa tiket : "<<tiket-(ip*10000)<<endl;
                        ipad=ipad+ip;
                        tiket=tiket-(ip*10000);
                        k=true;
                        }
                    }
                    }
                else if(s2==0){
                k=true;
                }
                else{
                    cout<<"";
                }
            }
        }else if(m==0){
        k=true;
        }else{
        cout<<"";
        }
    }return 0;
}
