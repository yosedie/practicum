#include<iostream>
#include<windows.h>
#include<conio.h>
#include<time.h>
using namespace std;
void menu(){
    cout<<"=== T5 : Spin Ball ===\n1. Play\n2. Highscore\n0. Exit\n>> ";
}
void sb(int time){
    cout<<"play time : "<<time<<endl;
}
void sc(int s){
    cout<<"score : "<<s<<endl;
}
void life(int l){
    cout<<"H H H - - "<<endl;
}
void papan(int width,int height,int playerPos,int&time,int&s,int&l,int&m,int npcPos1,int npcPos2,int npcPos3,char img1,char img2,char img3){
    cout<<"=== Spin Ball ==="<<endl;
    sb(time);
    sc(s);
    life(l);
    if(m==0){
    for(int x=0;x<12;x++){
            for(int y=0;y<12;y++){
                if((x==0&&y==0)){
                    cout<<"1";
                }else if(x==0&&y==11){
                    cout<<"2";
                }else if(x==11&&y==0){
                    cout<<"3";
                }else if(x==11&&y==11){
                    cout<<"4";
                }else if(x==0||x==11){
                    cout<<"* ";
                }else if(y==0||y==11){
                    cout<<"*";
                }else if(x==2&&y==3){
                    cout<<"# ";
                }else if(x==3&&y==3){
                    cout<<"# ";
                }else if(x==4&&y==3){
                    cout<<"# ";
                }else if(x==2&&y==5){
                    cout<<"O ";
                }else if(x==3&&y==6){
                    cout<<"# ";
                }else if(x==3&&y==7){
                    cout<<"# ";
                }else if(x==3&&y==8){
                    cout<<"# ";
                }else if(x==4&&y==6){
                    cout<<"H ";
                }else if(x==5&&y==4){
                    cout<<"# ";
                }else if(x==5&&y==5){
                    cout<<"# ";
                }else if(x==5&&y==7){
                    cout<<"# ";
                }else if(x==6&&y==7){
                    cout<<"# ";
                }else if(x==7&&y==7){
                    cout<<"# ";
                }else if(x==6&&y==2){
                    cout<<"# ";
                }else if(x==7&&y==2){
                    cout<<"# ";
                }else if(x==8&&y==2){
                    cout<<"# ";
                }else if(x==7&&y==3){
                    cout<<"# ";
                }else if(x==8&&y==3){
                    cout<<"O ";
                }else if(x==7&&y==4){
                    cout<<"O ";
                }else if(x==7&&y==8){
                    cout<<"# ";
                }else if(x==7&&y==9){
                    cout<<"# ";
                }else if(x==9&&y==5){
                    cout<<"# ";
                }else if(x==9&&y==6){
                    cout<<"# ";
                }else if(x==9&&y==4){
                    cout<<"# ";
                }else if(x==9&&y==7){
                    cout<<"# ";
                }else if(x==10&&y==1){
                    cout<<"|";
                }else if(x==10&&y==2){
                    cout<<"___";
                }else if(x==10&&y==3){
                    cout<<"| ";
                }else if(x==10&&y==5){
                    cout<<"|";
                }else if(x==10&&y==6){
                    cout<<"___";
                }else if(x==10&&y==7){
                    cout<<"|";
                }else if(x==10&&y==9){
                    cout<<"|__";
                }else if(x==10&&y==10){
                    cout<<"_|";
                }else{
                    cout<<"  ";
                }
            }cout<<endl;
            }
    }else if(m==1){
    for(int x=0;x<12;x++){
            for(int y=0;y<12;y++){
                if((x==0&&y==0)){
                    cout<<"2";
                }else if(x==0&&y==11){
                    cout<<"4";
                }else if(x==11&&y==0){
                    cout<<"1";
                }else if(x==11&&y==11){
                    cout<<"3";
                }else if(x==0||x==11){
                    cout<<"* ";
                }else if(y==0||y==11){
                    cout<<"*";
                }else if(x==5&&y==3){
                    cout<<"# ";
                }else if(x==3&&y==3){
                    cout<<"# ";
                }else if(x==4&&y==3){
                    cout<<"# ";
                }else if(x==6&&y==2){
                    cout<<"O ";
                }else if(x==4&&y==5){
                    cout<<"# ";
                }else if(x==4&&y==6){
                    cout<<"# ";
                }else if(x==4&&y==7){
                    cout<<"# ";
                }else if(x==5&&y==4){
                    cout<<"H ";
                }else if(x==3&&y==7){
                    cout<<"# ";
                }else if(x==2&&y==7){
                    cout<<"# ";
                }else if(x==6&&y==5){
                    cout<<"# ";
                }else if(x==7&&y==5){
                    cout<<"# ";
                }else if(x==8&&y==4){
                    cout<<"# ";
                }else if(x==8&&y==3){
                    cout<<"# ";
                }else if(x==8&&y==2){
                    cout<<"# ";
                }else if(x==8&&y==7){
                    cout<<"# ";
                }else if(x==9&&y==6){
                    cout<<"# ";
                }else if(x==8&&y==8){
                    cout<<"O ";
                }else if(x==7&&y==7){
                    cout<<"O ";
                }else if(x==9&&y==7){
                    cout<<"# ";
                }else if(x==9&&y==8){
                    cout<<"# ";
                }else if(x==4&&y==9){
                    cout<<"# ";
                }else if(x==5&&y==9){
                    cout<<"# ";
                }else if(x==6&&y==9){
                    cout<<"# ";
                }else if(x==7&&y==9){
                    cout<<"# ";
                }else if(x==10&&y==1){
                    cout<<"|";
                }else if(x==10&&y==2){
                    cout<<"___";
                }else if(x==10&&y==3){
                    cout<<"| ";
                }else if(x==10&&y==5){
                    cout<<"|";
                }else if(x==10&&y==6){
                    cout<<"___";
                }else if(x==10&&y==7){
                    cout<<"|";
                }else if(x==10&&y==9){
                    cout<<"|__";
                }else if(x==10&&y==10){
                    cout<<"_|";
                }else{
                    cout<<"  ";
                }
            }cout<<endl;
        }
    }else if(m==2){
    for(int x=0;x<12;x++){
            for(int y=0;y<12;y++){
                if((x==0&&y==0)){
                    cout<<"4";
                }else if(x==0&&y==11){
                    cout<<"3";
                }else if(x==11&&y==0){
                    cout<<"2";
                }else if(x==11&&y==11){
                    cout<<"1";
                }else if(x==0||x==11){
                    cout<<"* ";
                }else if(y==0||y==11){
                    cout<<"*";
                }else if(x==4&&y==2){
                    cout<<"# ";
                }else if(x==4&&y==3){
                    cout<<"# ";
                }else if(x==4&&y==4){
                    cout<<"# ";
                }else if(x==9&&y==6){
                    cout<<"O ";
                }else if(x==6&&y==4){
                    cout<<"# ";
                }else if(x==5&&y==4){
                    cout<<"# ";
                }else if(x==8&&y==5){
                    cout<<"# ";
                }else if(x==7&&y==5){
                    cout<<"H ";
                }else if(x==8&&y==4){
                    cout<<"# ";
                }else if(x==8&&y==3){
                    cout<<"# ";
                }else if(x==6&&y==6){
                    cout<<"# ";
                }else if(x==6&&y==7){
                    cout<<"# ";
                }else if(x==7&&y==8){
                    cout<<"# ";
                }else if(x==8&&y==8){
                    cout<<"# ";
                }else if(x==9&&y==8){
                    cout<<"# ";
                }else if(x==5&&y==9){
                    cout<<"# ";
                }else if(x==4&&y==9){
                    cout<<"# ";
                }else if(x==3&&y==8){
                    cout<<"O ";
                }else if(x==4&&y==7){
                    cout<<"O ";
                }else if(x==4&&y==8){
                    cout<<"# ";
                }else if(x==3&&y==9){
                    cout<<"# ";
                }else if(x==2&&y==5){
                    cout<<"# ";
                }else if(x==2&&y==6){
                    cout<<"# ";
                }else if(x==2&&y==4){
                    cout<<"# ";
                }else if(x==2&&y==7){
                    cout<<"# ";
                }else if(x==10&&y==1){
                    cout<<"|";
                }else if(x==10&&y==2){
                    cout<<"___";
                }else if(x==10&&y==3){
                    cout<<"| ";
                }else if(x==10&&y==5){
                    cout<<"|";
                }else if(x==10&&y==6){
                    cout<<"___";
                }else if(x==10&&y==7){
                    cout<<"|";
                }else if(x==10&&y==9){
                    cout<<"|__";
                }else if(x==10&&y==10){
                    cout<<"_|";
                }else{
                    cout<<"  ";
                }
            }cout<<endl;
        }
    }else if(m==3){
    for(int x=0;x<12;x++){
            for(int y=0;y<12;y++){
                if((x==0&&y==0)){
                    cout<<"3";
                }else if(x==0&&y==11){
                    cout<<"1";
                }else if(x==11&&y==0){
                    cout<<"4";
                }else if(x==11&&y==11){
                    cout<<"2";
                }else if(x==0||x==11){
                    cout<<"* ";
                }else if(y==0||y==11){
                    cout<<"*";
                }else if(x==7&&y==4){
                    cout<<"# ";
                }else if(x==8&&y==4){
                    cout<<"# ";
                }else if(x==9&&y==4){
                    cout<<"# ";
                }else if(x==5&&y==9){
                    cout<<"O ";
                }else if(x==3&&y==9){
                    cout<<"# ";
                }else if(x==3&&y==8){
                    cout<<"# ";
                }else if(x==3&&y==7){
                    cout<<"# ";
                }else if(x==6&&y==7){
                    cout<<"H ";
                }else if(x==6&&y==8){
                    cout<<"# ";
                }else if(x==7&&y==8){
                    cout<<"# ";
                }else if(x==8&&y==8){
                    cout<<"# ";
                }else if(x==4&&y==6){
                    cout<<"# ";
                }else if(x==5&&y==6){
                    cout<<"# ";
                }else if(x==7&&y==6){
                    cout<<"# ";
                }else if(x==7&&y==5){
                    cout<<"# ";
                }else if(x==3&&y==4){
                    cout<<"# ";
                }else if(x==2&&y==5){
                    cout<<"# ";
                }else if(x==3&&y==3){
                    cout<<"O ";
                }else if(x==4&&y==4){
                    cout<<"O ";
                }else if(x==2&&y==4){
                    cout<<"# ";
                }else if(x==2&&y==3){
                    cout<<"# ";
                }else if(x==4&&y==2){
                    cout<<"# ";
                }else if(x==5&&y==2){
                    cout<<"# ";
                }else if(x==6&&y==2){
                    cout<<"# ";
                }else if(x==7&&y==2){
                    cout<<"# ";
                }else if(x==10&&y==1){
                    cout<<"|";
                }else if(x==10&&y==2){
                    cout<<"___";
                }else if(x==10&&y==3){
                    cout<<"| ";
                }else if(x==10&&y==5){
                    cout<<"|";
                }else if(x==10&&y==6){
                    cout<<"___";
                }else if(x==10&&y==7){
                    cout<<"|";
                }else if(x==10&&y==9){
                    cout<<"|__";
                }else if(x==10&&y==10){
                    cout<<"_|";
                }else{
                    cout<<"  ";
                }
            }cout<<endl;
        }
    }
}
int Player(int&x,int&y,int&m){
    if(kbhit()){
            char moves=getch();
            if(moves =='W'||moves =='w'){
                if(y-1>0){
                    y--;
                }
            }else if(moves=='S'||moves=='s'){
                if(y+1<19){
                    y++;
                }
            }else if(moves=='D'||moves=='d'){
                if(x+1<19){
                    x++;
                }
            }else if(moves=='A'||moves=='a'){
                if(x-1>0){
                    x--;
                }
            }else if(moves=='P'||moves=='p'){
                system("pause");
            }else if(moves=='X'||moves=='x'){
                return 0;
            }else if(moves=='Q'||moves=='q'){
                m=m+1;if(m==4){m=0;}
            }
    }return x*100+y;
}
int npc(int&x,int&y,int playerPos,bool&hasRun,char&img){
    if(hasRun){
        do{
            x=rand()%7+1;
            y=rand()%7+1;
        }while((x==3&&y==2)||(x==3&&y==3)||(x==3&&y==4)||(x==5&&y==3)||(x==6&&y==3)||(x==5&&y==5)||(x==5&&y==6)||(x==4&&y==6));
        hasRun=false;
    }
    if(playerPos/100==x&&playerPos%100==y){
        img='T';
    return x*100+y;
    }
}
int checkTime(int time,bool&run){
    if(time>=100){
        run=false;
    }
}
int main(){
    int m,s0=0,s1,s2,s3,tiket=0;
    int easy=0,medium=0,hard=0;
    int e1,e2,e3,e4,e5;
    int m1,m2,m3,m4,m5,m6,m7,m8,m9,m10;
    int h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15;
    int ipad=0,bon=0,bol=0,ip,bn,bl;
    srand(time(0));
    e1=(rand()%1);e2=(rand()%1);e3=(rand()%1);e4=(rand()%1);e5=(rand()%1);
    m1=(rand()%1);m2=(rand()%1);m3=(rand()%1);m4=(rand()%1);m5=(rand()%1);
    m6=(rand()%1);m7=(rand()%1);m8=(rand()%1);m9=(rand()%1);m10=(rand()%1);
    h11=(rand()%1);h12=(rand()%1);h13=(rand()%1);h14=(rand()%1);h15=(rand()%1);
    h1=(rand()%1);h2=(rand()%1);h3=(rand()%1);h4=(rand()%1);h5=(rand()%1);
    h6=(rand()%1);h7=(rand()%1);h8=(rand()%1);h9=(rand()%1);h10=(rand()%1);
    int s=0,l;
    srand(time(NULL));
    int menuOpt;
    do{
        int time=0;
        int playerX=1;
        int playerY=1;
        menu();
        cin>>menuOpt;
        if(menuOpt==1){
            bool run=true;
            bool oneRun=true;
            bool twoRun=true;
            bool threeRun=true;
            int npc1X=0;
            int npc1Y=0;
            char img1='1';
            int npc2X=0;
            int npc2Y=0;
            char img2='2';
            int npc3X=0;
            int npc3Y=0;
            char img3='3';
            while(run){
                int sec=time/5;
                time++;
                int currPlayer=Player(playerX,playerY,m);
                papan(9,9,currPlayer,sec,s,l,m,npc(npc1X,npc1Y,currPlayer,oneRun,img1),
                npc(npc2X,npc2Y,currPlayer,twoRun,img2),
                npc(npc3X,npc3Y,currPlayer,threeRun,img3),img1,img2,img3);
                Sleep(200);
                system("cls");
                checkTime(sec,run);
            }
        }else if(menuOpt==2){
            cout<<"=== Highscore ==="<<endl;
            cout<<"1. -"<<endl;
            cout<<"2. -"<<endl;
            cout<<"3. -"<<endl;
        }
    }while(menuOpt!=0);
    cout<<"Terima kasih, sampai jumpa kembali";
}
