#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

 //nomor1
//int main()
//{
//    int c1,c2;
//    double a1,a2,a3,a4,b1,b2,b3,b4,t,c3;
//    cout<<"File 1 (Tb) : ";
//    cin>>a1;
//    cout<<"File 2 (GB) : ";
//    cin>>a2;
//    cout<<"File 3 (Mb) : ";
//    cin>>a3;
//    cout<<"File 4 (KB) : ";
//    cin>>a4;
//    cout<<"Hasil konversi"<<endl;
//
//    b1=a1*pow(1024,2)/8;
//    b2=a2*1024;
//    b3=a3/8;
//    b4=a4/1024;
//    t=b1+b2+b3+b4;
//    c1=t/pow(1024,2);
//    c2=t/1024;
//    c3=t-(c2*1024);
//
//    cout<< "File 1 (MB) : "<<b1<<endl;
//    cout<< "File 2 (MB) : "<<b2<<endl;
//    cout<< "File 3 (MB) : "<<b3<<endl;
//    cout<< "File 4 (MB) : "<<b4<<endl;
//    cout<<fixed<<setprecision(2);
//    cout<<"Total (MB) : "<<t<<endl;
//    cout<<"Total (TB, GB, MB) : "<<c1<<" TB "<<c2<<" GB "<<c3<<" MB "<<endl;
//    return 0;
//}

 //nomor2
int main()
{
    int a,a1,a2,a3,a4,b,b1,b2,b3,b4,ab1,ab2,ab3,ab4,t;
    int h1,h2,h3,h4,h5,h6,h7,h8,h9,h10,h11,h12,h13,h14,h15;
    cout<<"Angka 1 = ";
    cin>>a;
    cout<<"Angka 2 = ";
    cin>>b;

    a1=a/1000;
    b1=b/1000;
    a2=a/100%10;
    b2=b/100%10;
    a3=a/10%10;
    b3=b/10%10;
    a4=a%10;
    b4=b%10;
    ab1=(a1+b1)/10;
    ab2=(a2+b2)/10;
    ab3=(a3+b3)/10;
    ab4=(a4+b4)/10;
    t=a+b;

    cout<<"Proses penjumlahan"<<endl;
    cout<<ab1<<ab2<<ab3<<ab4<<endl;
    cout<<setw(5)<<a<<endl;
    cout<<setw(5)<<b<<endl;
    cout<<" ----+"<<endl;
    cout<<setw(5)<<t<<endl;
    cout<<" "<<endl;
    cout<<"Konversi Biner : ";

    h1=t%2;
    h2=t/2%2;
    h3=t/2/2%2;
    h4=t/2/2/2%2;
    h5=t/2/2/2/2%2;
    h6=t/2/2/2/2/2%2;
    h7=t/2/2/2/2/2/2%2;
    h8=t/2/2/2/2/2/2/2%2;
    h9=t/2/2/2/2/2/2/2/2%2;
    h10=t/2/2/2/2/2/2/2/2/2%2;
    h11=t/2/2/2/2/2/2/2/2/2/2%2;
    h12=t/2/2/2/2/2/2/2/2/2/2/2%2;
    h13=t/2/2/2/2/2/2/2/2/2/2/2/2%2;
    h14=t/2/2/2/2/2/2/2/2/2/2/2/2/2%2;
    h15=t/2/2/2/2/2/2/2/2/2/2/2/2/2/2%2;

    cout<<h15<<h14<<h13<<h12<<h11<<h10<<h9<<h8<<h7<<h6<<h5<<h4<<h3<<h2<<h1;
    return 0;
}
